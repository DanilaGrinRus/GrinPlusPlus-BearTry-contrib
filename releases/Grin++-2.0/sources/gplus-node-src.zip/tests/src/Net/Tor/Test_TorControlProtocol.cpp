#include <catch.hpp>

#include <asio.hpp>

#include <Net/Tor/TorControlClient.h>

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <istream>
#include <memory>
#include <string>
#include <system_error>
#include <thread>
#include <utility>
#include <vector>

namespace
{
	//
	// Minimal fake Tor control port. It accepts one connection and answers every
	// received command line with whatever the handler returns. Replies are byte
	// aligned (no parsing shortcut), so the test exercises the real client-side
	// reply handling including multi-line "250+" data blocks.
	//
	class FakeControlServer
	{
	public:
		using Handler = std::function<std::string(const std::string&)>;

		explicit FakeControlServer(Handler handler)
			: m_handler(std::move(handler)), m_acceptor(m_ioContext) { }

		~FakeControlServer()
		{
			m_stop = true;
			std::error_code ec;
			m_acceptor.close(ec);
			if (m_serverThread.joinable()) {
				m_serverThread.join();
			}
		}

		FakeControlServer(const FakeControlServer&) = delete;
		FakeControlServer& operator=(const FakeControlServer&) = delete;

		uint16_t Start()
		{
			const asio::ip::tcp::endpoint endpoint(asio::ip::make_address("127.0.0.1"), 0);
			m_acceptor.open(asio::ip::tcp::v4());
			m_acceptor.set_option(asio::ip::tcp::acceptor::reuse_address(true));
			m_acceptor.bind(endpoint);
			m_acceptor.listen(1);
			m_port = m_acceptor.local_endpoint().port();
			m_serverThread = std::thread([this]() { Serve(); });
			return m_port;
		}

	private:
		void Serve()
		{
			asio::ip::tcp::socket socket(m_ioContext);
			std::error_code ec;
			m_acceptor.accept(socket, ec);
			if (ec) {
				return;
			}

			asio::streambuf buffer;
			while (!m_stop) {
				asio::read_until(socket, buffer, '\n', ec);
				if (ec) {
					break;
				}

				std::istream stream(&buffer);
				std::string command;
				std::getline(stream, command);
				if (!command.empty() && command.back() == '\r') {
					command.pop_back();
				}

				const std::string reply = m_handler(command);
				asio::write(socket, asio::buffer(reply), ec);
				if (ec) {
					break;
				}
			}
		}

		Handler m_handler;
		asio::io_context m_ioContext;
		asio::ip::tcp::acceptor m_acceptor;
		std::thread m_serverThread;
		uint16_t m_port = 0;
		std::atomic_bool m_stop{ false };
	};

	TorControlClient::UPtr ConnectToFakeControl(const uint16_t port)
	{
		auto pClient = std::make_unique<TorControlClient>();
		REQUIRE(pClient->Connect(SocketAddress{ "127.0.0.1", port }));
		return pClient;
	}
}

TEST_CASE("TorControlClient - multi-line reply does not desynchronize the control stream")
{
	FakeControlServer server([](const std::string& command) -> std::string {
		if (command == "GETINFO onions/detached") {
			// Shape of a real Tor data reply: "250+<key>=" -> entries -> "." -> "250 OK".
			return "250+onions/detached=\r\nabcdefghijklmnop.onion\r\n.\r\n250 OK\r\n";
		}

		if (command == "SIGNAL HEARTBEAT") {
			return "250 OK\r\n";
		}

		return "552 Unrecognized command\r\n";
	});

	const TorControlClient::UPtr pClient = ConnectToFakeControl(server.Start());

	const std::vector<std::string> services = pClient->Invoke("GETINFO onions/detached\n");
	REQUIRE(services.size() == 2);
	REQUIRE(services[0] == "250+onions/detached=");
	REQUIRE(services[1] == "abcdefghijklmnop.onion");

	// Regression: the old parser threw on the data line and left "." and "250 OK"
	// in the socket, so this and every following command read a stale reply.
	REQUIRE(pClient->Invoke("SIGNAL HEARTBEAT\n").empty());
	REQUIRE(pClient->Invoke("SIGNAL HEARTBEAT\n").empty());
}

TEST_CASE("TorControlClient - Tor error replies surface the actual line")
{
	FakeControlServer server([](const std::string&) -> std::string {
		return "550 Onion address collision\r\n";
	});

	const TorControlClient::UPtr pClient = ConnectToFakeControl(server.Start());

	try {
		pClient->Invoke("ADD_ONION ED25519-V3:invalid\n");
		FAIL("Invoke should have thrown for a 5xx Tor reply");
	}
	catch (const TorException& e) {
		const std::string message = e.what();
		REQUIRE(message.find("550 Onion address collision") != std::string::npos);
	}
}

TEST_CASE("TorControlClient - concurrent commands are serialized")
{
	FakeControlServer server([](const std::string& command) -> std::string {
		const std::string prefix = "ECHO ";
		if (command.compare(0, prefix.size(), prefix) == 0) {
			return "250-ECHO=" + command.substr(prefix.size()) + "\r\n250 OK\r\n";
		}

		return "552 Unrecognized command\r\n";
	});

	const TorControlClient::UPtr pClient = ConnectToFakeControl(server.Start());

	constexpr size_t THREADS = 4;
	// static storage: used inside the thread lambda below, so it must not need
	// an explicit capture (MSVC C3493).
	static constexpr size_t COMMANDS_PER_THREAD = 25;

	std::atomic_int failures{ 0 };
	std::vector<std::thread> threads;
	threads.reserve(THREADS);
	for (size_t threadIndex = 0; threadIndex < THREADS; ++threadIndex) {
		threads.emplace_back([&pClient, &failures, threadIndex]() {
			for (size_t commandIndex = 0; commandIndex < COMMANDS_PER_THREAD; ++commandIndex) {
				const std::string payload = std::to_string(threadIndex) + "-" + std::to_string(commandIndex);
				try {
					const std::vector<std::string> reply = pClient->Invoke("ECHO " + payload + "\n");
					if (reply.size() != 1 || reply[0] != "250-ECHO=" + payload) {
						++failures;
					}
				}
				catch (const std::exception&) {
					++failures;
				}
			}
		});
	}

	for (std::thread& thread : threads) {
		thread.join();
	}

	// Without the transaction mutex the shared socket mixes commands and replies,
	// so a client sees another thread's payload (or a desynchronization error).
	REQUIRE(failures.load() == 0);
}

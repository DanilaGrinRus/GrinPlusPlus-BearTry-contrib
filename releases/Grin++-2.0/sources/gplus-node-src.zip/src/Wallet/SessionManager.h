#pragma once

#include <Common/Compat.h>
#include "LoggedInSession.h"

#include <Crypto/Models/SecretKey.h>
#include <Common/Secure.h>
#include <Core/Config.h>
#include <Net/Tor/TorProcess.h>
#include <Wallet/SessionToken.h>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

// Forward Declarations
class INodeClient;
class IWalletStore;
class IWalletManager;
class ForeignController;

//
// Testable session lifetime/limit policy. Contains no wallet or I/O
// dependencies: SessionManager feeds it timestamps and session metadata.
//
class SessionPolicy
{
public:
	using Clock = std::chrono::steady_clock;
	using TimePoint = Clock::time_point;
	using NowFunction = std::function<TimePoint()>;

	struct Limits
	{
		// F-03: absolute session lifetime and inactivity timeout.
		std::chrono::seconds absoluteTtl{ std::chrono::hours(12) };
		std::chrono::seconds idleTtl{ std::chrono::minutes(60) };
		// F-03: at most this many concurrent sessions per user; the least
		// recently used one is evicted. 0 disables the limit.
		std::size_t maxSessionsPerUser{ 5 };
	};

	enum class EExpiry
	{
		VALID,
		IDLE_EXPIRED,
		ABSOLUTE_EXPIRED
	};

	SessionPolicy();
	explicit SessionPolicy(const Limits& limits, NowFunction now = &Clock::now);

	const Limits& GetLimits() const noexcept { return m_limits; }
	TimePoint Now() const { return m_now(); }

	// An expired absolute lifetime wins over an expired idle timeout.
	EExpiry CheckExpiry(TimePoint createdAt, TimePoint lastUsedAt, TimePoint now) const;

	// Returns the least recently used session id; ties are broken by the
	// smallest session id. Returns std::nullopt for an empty list.
	static std::optional<uint64_t> SelectLruVictim(
		const std::vector<std::pair<uint64_t, TimePoint>>& sessions);

private:
	Limits m_limits;
	NowFunction m_now;
};

class SessionManager
{
public:
	SessionManager(
		const Config& config,
		const std::shared_ptr<const INodeClient>& pNodeClient,
		const std::shared_ptr<IWalletStore>& pWalletDB,
		std::unique_ptr<ForeignController>&& pForeignController
	);
	~SessionManager();

	static Locked<SessionManager> Create(
		const Config& config,
		const std::shared_ptr<const INodeClient>& pNodeClient,
		const std::shared_ptr<IWalletStore>& pWalletDB,
		IWalletManager& walletManager
	);

	void Authenticate(const std::string& username, const SecureString& password) const;
	SessionToken Login(
		const TorProcess::Ptr& pTorProcess,
		const std::string& username,
		const SecureString& password
	);
	SessionToken Login(
		const TorProcess::Ptr& pTorProcess,
		const std::string& username,
		const SecureVector& seed
	);
	void Logout(const SessionToken& token);

	// F-03: drops every session of the user and releases the wallet/listener.
	// Exposed as API for a separate logout_all RPC registration.
	void LogoutAll(const std::string& username);

	// F-03: token-validated overload for the logout_all RPC: resolves the user
	// from the presented session token, then drops every session of that user
	// (including the current one). Invalid/expired token -> SessionTokenException.
	void LogoutAll(const SessionToken& token);

	SecureVector GetSeed(const SessionToken& token) const;
	SecureVector GetSeed(const std::string& username, const SecureString& password) const;

	Locked<Wallet> GetWallet(const SessionToken& token) const;
	Locked<WalletImpl> GetWalletImpl(const SessionToken& token) const;

private:
	struct SessionEntry
	{
		SessionEntry(
			std::shared_ptr<LoggedInSession> pInSession,
			std::string inUsername,
			SessionPolicy::TimePoint inCreatedAt,
			SessionPolicy::TimePoint inLastUsedAt)
			: pSession(std::move(pInSession)),
			username(std::move(inUsername)),
			createdAt(inCreatedAt),
			lastUsedAt(inLastUsedAt) { }

		std::shared_ptr<LoggedInSession> pSession;
		std::string username;
		SessionPolicy::TimePoint createdAt;
		SessionPolicy::TimePoint lastUsedAt;
	};

	// Validates the token and the session lifetime. Touches last-used time.
	// Expired sessions are removed and reported as an invalid token.
	std::shared_ptr<LoggedInSession> RequireSession(const SessionToken& token) const;

	// Must not be called while m_sessionsMutex is held.
	bool HasAnySessionForUser(const std::string& username) const;
	// Stops the per-user listener and closes the wallet DB when the user has no
	// remaining sessions. Ignores cleanup errors (never masks the caller error).
	void ReleaseUserResourcesIfUnused(const std::string& username) const;
	// Removes one session; releases user resources if it was the last one.
	void RemoveSession(uint64_t sessionId);
	// F-03: evicts the least recently used session when the per-user cap is reached.
	void EvictLruSessionIfAtLimit(const std::string& username);

	mutable std::mutex m_sessionsMutex;
	// Mutable: RequireSession() touches last-used time and drops expired sessions
	// even when called through a const SessionManager (Locked<...>::Read()).
	mutable std::unordered_map<uint64_t, SessionEntry> m_sessionsById;

	SessionPolicy m_sessionPolicy;

	uint64_t m_nextSessionId;

	const Config& m_config;
	std::shared_ptr<const INodeClient> m_pNodeClient;
	std::shared_ptr<IWalletStore> m_pWalletDB;
	std::unique_ptr<ForeignController> m_pForeignController;
};

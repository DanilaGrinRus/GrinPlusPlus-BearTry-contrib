#include "WalletManagerImpl.h"
#include "CancelTx.h"
#include "Keychain/SeedEncrypter.h"
#include "Keychain/Mnemonic.h"
#include "SlateBuilder/ReceiveSlateBuilder.h"
#include "SlateBuilder/SendSlateBuilder.h"
#include "SlateBuilder/FinalizeSlateBuilder.h"
#include "SlateBuilder/CoinSelection.h"
#include "SlateBuilder/PostTransactionResult.h"
#include "WalletTxLoader.h"

#include <API/Wallet/Owner/Models/TxLifecycle.h>
#include <Wallet/Exceptions/InvalidMnemonicException.h>
#include <Wallet/WalletDB/WalletDB.h>
#include <Wallet/WalletTxType.h>
#include <Core/Exceptions/WalletException.h>
#include <Core/Util/FeeUtil.h>
#include <Crypto/CSPRNG.h>
#include <Common/Util/StringUtil.h>
#include <Common/Logger.h>
#include <Net/Tor/TorConnection.h>
#include <Net/Tor/TorProcess.h>
#include <cassert>
#include <optional>
#include <thread>

WalletManager::WalletManager(const Config& config, INodeClientPtr pNodeClient, std::shared_ptr<IWalletStore> pWalletStore)
	: m_config(config),
	m_pNodeClient(pNodeClient),
	m_pWalletStore(pWalletStore),
	m_sessionManager(SessionManager::Create(config, pNodeClient, pWalletStore, *this))
{

}

WalletManager::~WalletManager()
{
	LOG_INFO("Shutting down wallet manager");
}


bool WalletManager::ShouldReuseAddresses()
{
	return m_config.ShouldReuseAddresses();
}

Locked<Wallet> WalletManager::GetWallet(const SessionToken& token)
{
	SecureVector masterSeed = m_sessionManager.Read()->GetSeed(token);
	m_sessionManager.Read()->GetWalletImpl(token).Write()->RefreshOutputs(masterSeed, false);

	return m_sessionManager.Read()->GetWallet(token);
}

CreateWalletResponse WalletManager::InitializeNewWallet(
	const CreateWalletCriteria& criteria,
	const TorProcess::Ptr& pTorProcess)
{
	WALLET_INFO_F(
		"Creating new wallet with username {} and numWords {}",
		criteria.GetUsername(),
		criteria.GetNumWords()
	);

	const size_t entropyBytes = (4 * criteria.GetNumWords()) / 3;
	const SecureVector walletSeed = CSPRNG::GenerateRandomBytes(entropyBytes);
	const EncryptedSeed encryptedSeed = SeedEncrypter().EncryptWalletSeed(walletSeed, criteria.GetPassword());
	SecureString walletWords = Mnemonic::CreateMnemonic(walletSeed.data(), walletSeed.size());

	m_pWalletStore->CreateWallet(criteria.GetUsername(), encryptedSeed);

	WALLET_INFO_F("Wallet created with username: {}", criteria.GetUsername());

	// W-10 residual: create_wallet must not leave a wallet behind when the
	// implicit login fails (e.g. Tor/listener failure). The caller never received
	// the seed words, so the wallet would otherwise be unusable and a retry would
	// fail with "already exists". Best-effort rollback; if the session was
	// partially established the store refuses deletion and we keep the original
	// error instead of masking it.
	SessionToken token = [&]() {
		try {
			return m_sessionManager.Write()->Login(
				pTorProcess,
				criteria.GetUsername(),
				walletSeed
			);
		}
		catch (...) {
			try {
				m_pWalletStore->DeleteWallet(criteria.GetUsername());
				WALLET_WARNING_F("Rolled back wallet after failed implicit login: {}", criteria.GetUsername());
			}
			catch (const std::exception& e) {
				WALLET_ERROR_F("Failed to roll back wallet after failed implicit login: {}", e.what());
			}
			throw;
		}
	}();

	auto pWallet = m_sessionManager.Read()->GetWallet(token).Read();
	return CreateWalletResponse(
		token,
		pWallet->GetListenerPort(),
		walletWords,
		pWallet->GetSlatepackAddress(),
		pWallet->GetTorAddress()
	);
}

LoginResponse WalletManager::RestoreFromSeed(
	const RestoreWalletCriteria& criteria,
	const TorProcess::Ptr& pTorProcess)
{
	WALLET_INFO_F("Attempting to restore account with username: {}", criteria.GetUsername());

	// Only mnemonic decoding errors may be reported as an invalid mnemonic.
	SecureVector entropy;
	try
	{
		entropy = Mnemonic::ToEntropy(criteria.GetSeedWords());
	}
	catch (const std::exception& e)
	{
		WALLET_WARNING_F("Mnemonic invalid for username ({}). Error: {}", criteria.GetUsername(), e.what());
		throw InvalidMnemonicException();
	}

	try
	{
		const EncryptedSeed encryptedSeed = SeedEncrypter().EncryptWalletSeed(entropy, criteria.GetPassword());

		m_pWalletStore->CreateWallet(criteria.GetUsername(), encryptedSeed);

		WALLET_INFO_F("Wallet restored for username: {}", criteria.GetUsername());
		SessionToken token = [&]() {
			try {
				return m_sessionManager.Write()->Login(pTorProcess, criteria.GetUsername(), entropy);
			}
			catch (...) {
				try {
					m_pWalletStore->DeleteWallet(criteria.GetUsername());
					WALLET_WARNING_F("Rolled back restored wallet after failed implicit login: {}", criteria.GetUsername());
				}
				catch (const std::exception& e) {
					WALLET_ERROR_F("Failed to roll back restored wallet after failed implicit login: {}", e.what());
				}
				throw;
			}
		}();

		auto pWallet = m_sessionManager.Read()->GetWallet(token).Read();
		return LoginResponse(
			token,
			pWallet->GetListenerPort(),
			pWallet->GetSlatepackAddress(),
			pWallet->GetTorAddress()
		);
	}
	catch (const std::exception& e)
	{
		// Wallet creation / login failures are not mnemonic errors: preserve the
		// original reason instead of mislabeling it as InvalidMnemonicException.
		WALLET_ERROR_F("Failed to restore wallet for username ({}): {}", criteria.GetUsername(), e.what());
		throw;
	}
}

SecureString WalletManager::GetSeedWords(const GetSeedPhraseCriteria& criteria)
{
	const SecureVector masterSeed = m_sessionManager.Read()->GetSeed(
		criteria.GetUsername(),
		criteria.GetPassword()
	);
	return Mnemonic::CreateMnemonic(masterSeed.data(), masterSeed.size());
}

void WalletManager::CheckForOutputs(const SessionToken& token, const bool fromGenesis)
{
	try
	{
		const SecureVector masterSeed = m_sessionManager.Read()->GetSeed(token);
		Locked<WalletImpl> wallet = m_sessionManager.Read()->GetWalletImpl(token);

		wallet.Write()->RefreshOutputs(masterSeed, fromGenesis);
	}
	catch(const std::exception& e)
	{
		WALLET_ERROR_F("Exception thrown: {}", e.what());
		throw WALLET_EXCEPTION(e.what());
	}
}

std::optional<TorAddress> WalletManager::AddTorListener(const SessionToken& token, const KeyChainPath& path, const TorProcess::Ptr& pTorProcess)
{
	Locked<Wallet> wallet = m_sessionManager.Read()->GetWallet(token);
	Locked<WalletImpl> walletImpl = m_sessionManager.Read()->GetWalletImpl(token);

	KeyChain keyChain = KeyChain::FromSeed(m_sessionManager.Read()->GetSeed(token));
	ed25519_keypair_t torKey = keyChain.DeriveED25519Key(path);

	TorAddress torAddress = TorAddressParser::FromPubKey(ED25519::CalculatePubKey(torKey.secret_key));
	
	wallet.Write()->SetTorAddress(torAddress);
	walletImpl.Write()->SetTorAddress(torAddress);

	pTorProcess->AddListener(torKey.secret_key, wallet.Read()->GetListenerPort());

	return wallet.Read()->GetTorAddress();
}

bool WalletManager::RemoveCurrentTorListener(const SessionToken& token, const TorProcess::Ptr& pTorProcess)
{
	Locked<Wallet> wallet = m_sessionManager.Read()->GetWallet(token);
	Locked<WalletImpl> walletImpl = m_sessionManager.Read()->GetWalletImpl(token);

	KeyChain keyChain = KeyChain::FromSeed(m_sessionManager.Read()->GetSeed(token));
	
	int currentIndex = wallet.Read()->GetDatabase().Read()->GetCurrentAddressIndex(KeyChainPath::FromString("m/0/0"));
	KeyChainPath currentPath = KeyChainPath::FromString("m/0/1").GetChild(currentIndex);
	ed25519_keypair_t torKey = keyChain.DeriveED25519Key(currentPath);
	
	return pTorProcess->RemoveListener(TorAddressParser::FromPubKey(ED25519::CalculatePubKey(torKey.secret_key)));
}

KeyChainPath WalletManager::IncreaseAddressKeyChainPathIndex(const SessionToken& token)
{
	Locked<Wallet> wallet = m_sessionManager.Read()->GetWallet(token);
	Locked<WalletImpl> walletImpl = m_sessionManager.Read()->GetWalletImpl(token);

	KeyChainPath userPath = KeyChainPath::FromString("m/0/0"); // FUTURE: Support multiple account paths
	
	// now let's increase the index
	int nextIndex = wallet.Write()->GetDatabase().Write()->IncreaseAddressIndex(userPath);
	// after increasing the index we should then add the tor listener again using the new derived key
	return KeyChainPath::FromString("m/0/1").GetChild(nextIndex);
}

std::vector<GrinStr> WalletManager::GetAllAccounts() const
{
	return m_pWalletStore->GetAccounts();
}

LoginResponse WalletManager::Login(
	const LoginCriteria& criteria,
	const TorProcess::Ptr& pTorProcess)
{
	WALLET_INFO_F("Attempting to login with username: {}", criteria.GetUsername());

	std::optional<SessionToken> sessionToken;
	try
	{
		sessionToken = m_sessionManager.Write()->Login(
			pTorProcess,
			criteria.GetUsername(),
			criteria.GetPassword()
		);

		WALLET_INFO_F("Login successful for username: {}", criteria.GetUsername());
		CheckForOutputs(sessionToken.value(), false);

		auto pWallet = m_sessionManager.Read()->GetWallet(sessionToken.value()).Read();

		// Crash-between-commit-and-post recovery signal: finalized transactions
		// whose broadcast outcome is unknown (e.g. the process died after the
		// finalize commit but before/while posting). They are safe to repost.
		{
			const SecureVector masterSeed = m_sessionManager.Read()->GetSeed(sessionToken.value());
			const std::vector<WalletTx> walletTxs = pWallet->GetDatabase().Read()->GetTransactions(masterSeed);
			size_t pendingBroadcasts = 0;
			size_t reposted = 0;
			size_t repostFailed = 0;
			for (const WalletTx& walletTx : walletTxs)
			{
				if (walletTx.GetType() == EWalletTxType::SENDING_FINALIZED
					&& !walletTx.GetConfirmationHeight().has_value()
					&& !walletTx.GetConfirmationTime().has_value())
				{
					++pendingBroadcasts;

					if (!walletTx.GetTransaction().has_value())
					{
						++repostFailed;
						continue;
					}

					try
					{
						PostMethodDTO postMethod(EPostMethod::FLUFF, std::nullopt);
						if (PostTransaction(walletTx.GetTransaction().value(), postMethod, pTorProcess))
						{
							++reposted;
						}
						else
						{
							++repostFailed;
						}
					}
					catch (const std::exception& e)
					{
						++repostFailed;
						WALLET_WARNING_F(
							"Auto-repost at login failed for a finalized transaction: {}",
							e.what()
						);
					}
				}
			}

			if (pendingBroadcasts > 0)
			{
				WALLET_WARNING_F(
					"{} finalized transaction(s) had an unknown broadcast state (crash/restart?); "
					"auto-repost attempted at login: {} succeeded, {} failed. "
					"Failures can be retried with repost_tx and inspected with get_tx_status.",
					pendingBroadcasts,
					reposted,
					repostFailed
				);
			}
		}

		return LoginResponse(
			sessionToken.value(),
			pWallet->GetListenerPort(),
			pWallet->GetSlatepackAddress(),
			pWallet->GetTorAddress()
		);
	}
	catch (std::exception& e)
	{
		WALLET_ERROR_F("Error ({}) while attempting to login as: {}", e.what(), criteria.GetUsername());

		if (sessionToken.has_value())
		{
			// F-13: a login that fails after the session was created (e.g. a
			// read-only wallet.db during CheckForOutputs) must not leak the
			// session or the opened wallet handle.
			try
			{
				m_sessionManager.Write()->Logout(sessionToken.value());
			}
			catch (const std::exception& cleanupError)
			{
				WALLET_ERROR_F(
					"Failed to discard the session after a failed login for '{}': {}",
					criteria.GetUsername(),
					cleanupError.what()
				);
			}
		}

		throw;
	}
}

void WalletManager::Logout(const SessionToken& token)
{
	m_sessionManager.Write()->Logout(token);
}

void WalletManager::LogoutAll(const SessionToken& token)
{
	m_sessionManager.Write()->LogoutAll(token);
}

void WalletManager::DeleteWallet(const GrinStr& username, const SecureString& password)
{
	WALLET_WARNING_F("Attempting to delete wallet with username: {}", username);

	try
	{
		GrinStr usernameLower = username.ToLower();
		m_sessionManager.Read()->Authenticate(usernameLower, password);

		m_pWalletStore->DeleteWallet(usernameLower);
	}
	catch (std::exception& e)
	{
		WALLET_ERROR_F("Error ({}) while attempting to delete wallet: {}", e.what(), username);
		throw WALLET_EXCEPTION(e.what());
	}
}

void WalletManager::ChangePassword(
	const GrinStr& username,
	const SecureString& currentPassword,
	const SecureString& newPassword)
{
	GrinStr usernameLower = username.ToLower();
	EncryptedSeed encrypted = m_pWalletStore->LoadWalletSeed(usernameLower);
	SecureVector walletSeed = SeedEncrypter().DecryptWalletSeed(encrypted, currentPassword);

	// Valid password - Re-encrypt seed
	EncryptedSeed newSeed = SeedEncrypter().EncryptWalletSeed(walletSeed, newPassword);
	m_pWalletStore->ChangePassword(usernameLower, newSeed);
}

Slate WalletManager::Send(const SendCriteria& sendCriteria)
{
	const SecureVector masterSeed = m_sessionManager.Read()->GetSeed(sendCriteria.GetToken());
	Locked<WalletImpl> wallet = m_sessionManager.Read()->GetWalletImpl(sendCriteria.GetToken());

	std::vector<SlatepackAddress> recipients;

	if (sendCriteria.GetAddress().has_value()) {
		try {
			SlatepackAddress slatepack_address = SlatepackAddress::Parse(sendCriteria.GetAddress().value());
			recipients.emplace_back(std::move(slatepack_address));
		}
		catch (std::exception&) {}
	}

	return SendSlateBuilder(m_pNodeClient).BuildSendSlate(
		wallet,
		masterSeed,
		sendCriteria.GetAmount().value_or(0),
		sendCriteria.GetFeeBase(),
		sendCriteria.GetNumOutputs(),
		!sendCriteria.GetAmount().has_value(), // TODO: Implement
		sendCriteria.GetAddress(),
		sendCriteria.GetSelectionStrategy(),
		sendCriteria.GetSlateVersion(),
		recipients
	);
}

Slate WalletManager::Receive(const ReceiveCriteria& receiveCriteria)
{
	const SecureVector masterSeed = m_sessionManager.Read()->GetSeed(receiveCriteria.GetToken());
	Locked<WalletImpl> wallet = m_sessionManager.Read()->GetWalletImpl(receiveCriteria.GetToken());

	std::vector<SlatepackAddress> recipients;
	if (receiveCriteria.GetSlatepack().has_value() && receiveCriteria.GetSlatepack().value().m_mode == SlatepackMessage::ENCRYPTED) {
		recipients.push_back(receiveCriteria.GetSlatepack().value().m_sender);
	}

	// The builder validates stage/amount/ttl against the current chain height
	// before any output or wallet transaction is persisted.
	const uint64_t chainHeight = m_pNodeClient->GetChainHeight();

	Slate slate = ReceiveSlateBuilder().AddReceiverData(
		wallet,
		masterSeed,
		receiveCriteria.GetSlate(),
		receiveCriteria.GetAddress(),
		recipients,
		chainHeight
	);

	return slate;
}

Slate WalletManager::Finalize(const FinalizeCriteria& finalizeCriteria, const TorProcess::Ptr& pTorProcess)
{
	const SecureVector masterSeed = m_sessionManager.Read()->GetSeed(finalizeCriteria.GetToken());
	Locked<Wallet> wallet = m_sessionManager.Read()->GetWallet(finalizeCriteria.GetToken());

	FinalizeSlateBuilder::FinalizeResult finalized = FinalizeSlateBuilder(wallet.Write().GetShared(), m_pNodeClient).Finalize(
		finalizeCriteria.GetSlate()
	);

	const std::string slateId = uuids::to_string(finalized.slate.GetId());

	if (finalizeCriteria.GetPostMethod().has_value())
	{
		const bool posted = PostTransaction(
			finalized.transaction,
			finalizeCriteria.GetPostMethod().value(),
			pTorProcess
		);

		if (!posted)
		{
			const std::string broadcastError = "The node rejected the transaction or did not accept it.";
			TxBroadcastRegistry::Record(slateId, EBroadcastResult::FAILED, broadcastError);

			// Do NOT report this as a successful finalize: the wallet state is
			// SENDING_FINALIZED (safe, coins stay locked) but nothing was
			// published. repost_tx can retry once the cause is fixed.
			WALLET_ERROR_F(
				"Transaction {} (slate {}) was finalized but FAILED to broadcast. Use repost_tx to retry.",
				finalized.walletTxId,
				slateId
			);

			throw TxBroadcastException(
				"Transaction was finalized but could not be broadcast.",
				__func__,
				slateId,
				broadcastError
			);
		}

		TxBroadcastRegistry::Record(
			slateId,
			m_pNodeClient->IsPoolAcceptanceAuthoritative()
				? EBroadcastResult::ACCEPTED
				: EBroadcastResult::POSTED
		);
		WALLET_INFO_F("Transaction {} (slate {}) finalized and broadcast.", finalized.walletTxId, slateId);
	}
	else
	{
		// Offline slatepack flow: the slate is finalized but the caller did not
		// ask to publish it.
		TxBroadcastRegistry::Record(slateId, EBroadcastResult::NOT_REQUESTED);
		WALLET_INFO_F("Transaction {} (slate {}) finalized; broadcast not requested.", finalized.walletTxId, slateId);
	}

	return finalized.slate;
}

bool WalletManager::PostTransaction(
	const Transaction& transaction,
	const PostMethodDTO& postMethod,
	const TorProcess::Ptr& pTorProcess)
{
	const EPostMethod method = postMethod.GetMethod();
	if (method == EPostMethod::JOIN)
	{
		if (!postMethod.GetGrinJoinAddress().has_value())
		{
			WALLET_ERROR("GrinJoin address is missing; cannot post transaction.");
			return false;
		}

		try
		{
			auto pTorConnection = pTorProcess->Connect(postMethod.GetGrinJoinAddress().value());
			if (pTorConnection == nullptr)
			{
				WALLET_ERROR("Failed to connect to GrinJoin; transaction was not posted.");
				return false;
			}

			Json::Value params;
			params["tx"] = transaction.ToJSON();
			RPC::Request receiveTxRequest = RPC::Request::BuildRequest("submit_tx", params);
			RPC::Response receiveTxResponse = pTorConnection->Invoke(receiveTxRequest, "/v1");

			const PostTransactionOutcome outcome = ParsePostTransactionResponse(receiveTxResponse);
			if (outcome.status != EPostTransactionStatus::POSTED)
			{
				WALLET_ERROR_F("GrinJoin submit_tx was not accepted: {}", outcome.error);
				return false;
			}

			return true;
		}
		catch (std::exception& e)
		{
			WALLET_ERROR_F("Exception thrown while posting to GrinJoin: {}", e.what());
			return false;
		}
	}

	const EPoolType poolType = (method == EPostMethod::FLUFF) ? EPoolType::MEMPOOL : EPoolType::STEMPOOL;

	bool posted = false;
	try
	{
		posted = m_pNodeClient->PostTransaction(std::make_shared<Transaction>(transaction), poolType);
	}
	catch (const std::exception& e)
	{
		// A transport/node failure must not escape as an uncaught exception:
		// finalize/repost need to keep the wallet state consistent and return a
		// coded error that the caller can retry.
		WALLET_ERROR_F("Node error while posting transaction: {}", e.what());
		posted = false;
	}

	if (!posted)
	{
		WALLET_ERROR("Node rejected the transaction or did not accept it into the pool.");
	}

	return posted;
}

bool WalletManager::RepostTx(const RepostTxCriteria& criteria, const TorProcess::Ptr& pTorProcess)
{
	Locked<Wallet> wallet = GetWallet(criteria.GetToken());

	auto pWalletTx = wallet.Read()->GetTransactionById(criteria.GetTxId());
	if (pWalletTx == nullptr)
	{
		WALLET_WARNING_F("Repost: transaction {} not found.", criteria.GetTxId());
		return false;
	}

	if (!pWalletTx->GetTransaction().has_value())
	{
		WALLET_WARNING_F("Repost: transaction {} has no stored finalized transaction.", criteria.GetTxId());
		return false;
	}

	if (pWalletTx->GetConfirmationHeight().has_value() || pWalletTx->GetConfirmationTime().has_value())
	{
		WALLET_WARNING_F("Repost: transaction {} is already confirmed.", criteria.GetTxId());
		return false;
	}

	if (pWalletTx->GetType() != EWalletTxType::SENDING_FINALIZED)
	{
		WALLET_WARNING_F(
			"Repost: transaction {} is in status {}; only finalized transactions can be reposted.",
			criteria.GetTxId(),
			WalletTxType::ToString(pWalletTx->GetType())
		);
		return false;
	}

	const std::string slateId = pWalletTx->GetSlateId().has_value()
		? uuids::to_string(pWalletTx->GetSlateId().value())
		: std::string();

	PostMethodDTO postMethod(criteria.GetMethod(), criteria.GetGrinJoinAddress());
	const bool reposted = PostTransaction(pWalletTx->GetTransaction().value(), postMethod, pTorProcess);

	if (reposted)
	{
		TxBroadcastRegistry::Record(
			slateId,
			m_pNodeClient->IsPoolAcceptanceAuthoritative()
				? EBroadcastResult::ACCEPTED
				: EBroadcastResult::POSTED
		);
		WALLET_INFO_F("Transaction {} (slate {}) reposted successfully.", criteria.GetTxId(), slateId);
	}
	else
	{
		TxBroadcastRegistry::Record(slateId, EBroadcastResult::FAILED, "repost rejected");
		WALLET_ERROR_F("Transaction {} (slate {}) could not be reposted.", criteria.GetTxId(), slateId);
	}

	return reposted;
}

namespace WalletAPI
{
	//
	// Creates a new instance of the Wallet server.
	//
	WALLET_API IWalletManagerPtr CreateWalletManager(const Config& config, INodeClientPtr pNodeClient)
	{
		std::shared_ptr<IWalletStore> pWalletDB = WalletDBAPI::OpenWalletDB(config);
		return std::shared_ptr<IWalletManager>(new WalletManager(config, pNodeClient, pWalletDB));
	}
}
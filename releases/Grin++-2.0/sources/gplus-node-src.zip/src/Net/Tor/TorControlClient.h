#pragma once

#include <Net/Clients/Client.h>
#include <Net/Tor/TorException.h>
#include <Common/Logger.h>
#include <filesystem>
#include <mutex>
#include <vector>

static const std::chrono::seconds TOR_CONTROL_TIMEOUT = std::chrono::seconds(3);
static const std::chrono::seconds TOR_STARTUP_TIMEOUT = std::chrono::seconds(10);

class TorControlClient : public Client<std::string, std::vector<std::string>>
{
public:
	using UPtr = std::unique_ptr<TorControlClient>;

	static TorControlClient::UPtr Connect(const uint16_t control_port, const std::string& password);

	//
	// T2: authenticate with Tor's CookieAuthentication file (32-byte cookie,
	// sent as hex). Avoids any hardcoded control password.
	//
	static TorControlClient::UPtr ConnectCookie(const uint16_t control_port, const std::filesystem::path& cookieFile);

	//
	// Connects the control socket without authenticating it. The factories above
	// use it before AUTHENTICATE; it is also the connect step used by the
	// protocol tests (a fake control server needs no cookie/authentication).
	//
	bool Connect(const SocketAddress& address);

	//
	// Writes the given string to the socket and reads the complete reply.
	//
	// Tor control replies are line oriented and multi-line replies exist:
	//   * "250-<text>" intermediate/success lines, terminated by "250 OK";
	//   * "250+<keyword>=" opens a data block that ends with a "." line and is
	//     followed by the "250 OK" terminator;
	//   * "4xx"/"5xx" error lines.
	// A command/reply transaction is serialized by m_transactionMutex because a
	// single control socket is shared by the Tor init thread (heartbeat,
	// ADD_ONION) and API threads (DEL_ONION): without serialization the replies
	// interleave and the protocol desynchronizes permanently.
	//
	// throws TorException - If Tor replies with an error line or the reply is
	// malformed. The message always contains the actual reply line.
	//
	std::vector<std::string> Invoke(const std::string& request) final;

private:
	bool IsBootstrapped();

	// Serializes one full command/reply transaction on the shared control socket.
	std::mutex m_transactionMutex;
};

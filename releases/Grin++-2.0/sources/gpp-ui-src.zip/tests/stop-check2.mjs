import { chromium } from "playwright-core";
const b = await chromium.connectOverCDP("http://127.0.0.1:9231");
const p = b.contexts()[0].pages()[0];
await p.waitForSelector(".app .toolbar", { timeout: 20000 });
await p.locator('.toolbar button[title="Статус"]').click();
await p.waitForTimeout(500);
await p.getByRole("button", { name: "Запустить", exact: true }).click();
await p.waitForTimeout(20000);
const started = (await p.locator("main").innerText()).replace(/\n/g," | ").slice(0,220);
console.log("STARTED:", started);
const t0 = Date.now();
await p.getByRole("button", { name: "Стоп", exact: true }).click();
await p.waitForTimeout(300);
let ms = null;
for (let i=0;i<100;i++) {
  const txt = await p.locator("main").innerText();
  if (txt.includes("остановлена")) { ms = Date.now()-t0; break; }
  await p.waitForTimeout(200);
}
console.log("STOP_MS:", ms);
await b.close();

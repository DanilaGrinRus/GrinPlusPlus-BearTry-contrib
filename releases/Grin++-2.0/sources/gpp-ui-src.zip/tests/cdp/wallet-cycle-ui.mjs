// UI-проверка результата цикла: балансы и история после подтверждённой транзакции.
import { chromium } from "playwright-core";
import { writeFileSync, mkdirSync } from "node:fs";

const ev = process.argv[2] ?? "C:\\DHW\\Gplus\\evidence\\gplus-2.0.0-20261111\\wallet-cycle";
mkdirSync(ev, { recursive: true });
const out = { steps: [] };
const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
const page = browser.contexts()[0].pages()[0];
await page.waitForSelector(".app .toolbar", { timeout: 30000 });
const selects = page.locator(".toolbar select");
await selects.nth(0).selectOption("en").catch(() => {});
await selects.nth(1).selectOption("FLOONET").catch(() => {});
await page.waitForTimeout(1500);

async function shot(n) { try { await page.screenshot({ path: `${ev}\\${n}.png` }); } catch {} }
async function goTo(title) { await page.locator(`.icon-btn[title="${title}"]`).click(); await page.waitForTimeout(700); }
async function logoutIfNeeded() {
  const l = page.locator('.icon-btn[title="Log out"]');
  if (await l.count()) { await l.first().click(); await page.waitForTimeout(900); }
}
async function login(user) {
  await goTo("Wallet");
  await page.waitForTimeout(600);
  if (await page.locator(".spendable").count() === 0) {
    const link = page.getByRole("button", { name: /^login$/i });
    if (await link.count()) { await link.first().click(); await page.waitForTimeout(400); }
    await page.fill('input[placeholder="username"]', user);
    await page.fill('input[placeholder="password"]', "TestnetOnly!2026");
    await page.getByRole("button", { name: /^login$/i }).last().click();
    await page.waitForSelector(".spendable", { timeout: 600000 });
  }
  await page.waitForTimeout(3000);
  return (await page.locator(".spendable").innerText()).trim();
}

try {
  await logoutIfNeeded();
  const balCoin9 = await login("coin9");
  out.steps.push({ step: "coin9_balance", spendable: balCoin9 });
  await shot("10-coin9-balance");
  await goTo("History");
  await page.waitForTimeout(3000);
  const histCoin9 = (await page.locator(".content").innerText()).replace(/\s+/g, " ");
  out.steps.push({ step: "coin9_history", text: histCoin9.slice(0, 700) });
  await shot("11-coin9-history");
  await logoutIfNeeded();

  const balRcv = await login("rcv1");
  out.steps.push({ step: "rcv1_balance", spendable: balRcv });
  await shot("12-rcv1-balance");
  await goTo("History");
  await page.waitForTimeout(3000);
  const histRcv = (await page.locator(".content").innerText()).replace(/\s+/g, " ");
  out.steps.push({ step: "rcv1_history", text: histRcv.slice(0, 700) });
  await shot("13-rcv1-history");
} catch (e) {
  out.steps.push({ step: "error", message: String(e).slice(0, 500) });
  await shot("99-error");
} finally {
  writeFileSync(`${ev}\\wallet-cycle-ui.json`, JSON.stringify(out, null, 2), "utf8");
  console.log(JSON.stringify(out, null, 2).slice(0, 2500));
  await browser.close();
}

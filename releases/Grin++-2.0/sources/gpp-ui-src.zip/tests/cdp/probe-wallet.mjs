// Диагностический зонд: что происходит после нажатия «создать».
import { chromium } from "playwright-core";

const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
const context = browser.contexts()[0];
const page = context.pages()[0];
const consoleErrors = [];
page.on("console", (m) => {
  if (m.type() === "error") consoleErrors.push(m.text().slice(0, 200));
});
page.on("pageerror", (e) => consoleErrors.push("pageerror: " + String(e).slice(0, 200)));

await page.waitForSelector(".app .chrome", { timeout: 15000 });
await page.locator('.nav-item:has-text("Кошелёк")').click();
await page.waitForSelector('input[placeholder="username"]');
await page.fill('input[placeholder="username"]', `probe-${Date.now() % 100000}`);
await page.fill('input[placeholder="password"]', "TestnetOnly!2026");
const btn = page.getByRole("button", { name: /создать/i }).first();
console.log("disabled:", await btn.isDisabled());
await btn.click();
await page.waitForTimeout(8000);
const dump = {
  chrome: (await page.locator(".chrome").innerText()).replace(/\s+/g, " ").slice(0, 200),
  hints: await page.locator(".hint, .ok-text, .err-text").allInnerTexts(),
  disabledAfter: await btn.isDisabled(),
  consoleErrors,
};
console.log(JSON.stringify(dump, null, 2));
await browser.close();

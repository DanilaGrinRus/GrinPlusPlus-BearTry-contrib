import { chromium } from "playwright-core";
const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
const page = browser.contexts()[0].pages()[0];
await page.waitForSelector(".app .toolbar", { timeout: 20000 });
const out = "C:\\DHW\\Gplus\\evidence\\ui-tauri-20261110\\cdp";
const selects = page.locator(".toolbar select");
await selects.nth(1).selectOption("FLOONET").catch(() => {});
await page.waitForTimeout(2000);
await page.locator('.icon-btn[title="Кошелёк"]').click();
await page.waitForTimeout(1500);
if (await page.locator(".spendable").count() === 0) {
  const link = page.getByRole("button", { name: /войти|login/i });
  if (await link.count()) { await link.first().click(); await page.waitForTimeout(500); }
  if (await page.locator('input[placeholder="username"]').count() === 0) {
    console.log("no login form; body:", (await page.locator(".content").innerText()).slice(0,300).replace(/\n/g," | "));
  }
  await page.fill('input[placeholder="username"]', "coin9");
  await page.fill('input[placeholder="password"]', "TestnetOnly!2026");
  await page.getByRole("button", { name: /войти|login/i }).last().click();
  await page.waitForSelector(".spendable", { timeout: 600000 });
}
await page.waitForTimeout(2500);
await page.screenshot({ path: out + "\\ui-p1-wallet.png" });
await page.locator('.icon-btn[title="Отправка"]').click();
await page.waitForTimeout(1500);
await page.screenshot({ path: out + "\\ui-p1-payments.png" });
const footer = await page.locator("footer").innerText();
console.log("footer:", footer.replace(/\n/g, " | "));
console.log("tabs:", (await page.locator(".tabs").first().innerText()).replace(/\n/g, " | "));
await browser.close();

// CDP smoke-сценарии для Tauri-приложения (WebView2 remote debugging).
//
// Запускается под playwright-core: chromium.connectOverCDP('http://127.0.0.1:9222').
// Пишет JSONL-строки и скриншоты в каталог, переданный аргументом.
//
// Сценарии намеренно короткие (7 штук), проверяют реальные пути UI → invoke → Rust.

import { chromium } from "playwright-core";
import { mkdirSync, appendFileSync } from "node:fs";
import { join } from "node:path";

const outDir = process.argv[2] ?? ".";
const cdpUrl = process.argv[3] ?? "http://127.0.0.1:9222";
const jsonl = join(outDir, "cdp-smoke.jsonl");
mkdirSync(outDir, { recursive: true });

let failures = 0;

function record(name, verdict, detail = {}, note = "") {
  appendFileSync(
    jsonl,
    JSON.stringify({ ts: new Date().toISOString(), case: name, verdict, note, detail }) + "\n",
  );
  console.log(`[${verdict}] ${name} ${note}`);
  if (verdict === "FAIL") failures += 1;
}

async function shot(page, name) {
  try {
    await page.screenshot({ path: join(outDir, `cdp-${name}.png`), fullPage: false });
  } catch (e) {
    record(`screenshot_${name}`, "FAIL", { error: String(e) });
  }
}

const browser = await chromium.connectOverCDP(cdpUrl);
const context = browser.contexts()[0];
const page = context.pages()[0] ?? (await context.waitForEvent("page"));

await page.waitForLoadState("domcontentloaded");

// 1. Приложение отрисовано, навигация на месте
try {
  await page.waitForSelector(".app .chrome", { timeout: 15000 });
  const navCount = await page.locator(".nav-item").count();
  const brand = await page.locator(".brand").innerText();
  record("app_rendered", navCount === 8 && brand.includes("Grin++") ? "PASS" : "FAIL", {
    navCount,
    brand,
  });
} catch (e) {
  record("app_rendered", "FAIL", { error: String(e) });
}

// 2. Топбар и статус ноды (нода уже запущена стендом)
try {
  const badge = (await page.locator(".topbar .badge").first().innerText()).trim();
  const topbar = await page.locator(".topbar").innerText();
  record("topbar_status", badge.length > 0 && topbar.length > 0 ? "PASS" : "FAIL", {
    badge,
    topbar: topbar.replace(/\s+/g, " ").slice(0, 160),
  });
  await shot(page, "status");
} catch (e) {
  record("topbar_status", "FAIL", { error: String(e) });
}

// 3. Создание кошелька через форму
let walletReady = false;
const user = `ui-${Date.now() % 1000000}`;
try {
  await page.locator('.nav-item:has-text("Кошелёк")').click();
  await page.waitForSelector('input[placeholder="username"]');
  await page.fill('input[placeholder="username"]', user);
  await page.fill('input[placeholder="password"]', "TestnetOnly!2026");
  await page.getByRole("button", { name: "Создать", exact: true }).click();
  await page.waitForSelector("text=кошелёк создан", { timeout: 120000 });
  walletReady = true;
  record("create_wallet", "PASS", { user });
  await shot(page, "wallet-created");
} catch (e) {
  const errs = await page.locator(".err-text").allInnerTexts().catch(() => []);
  const hints = await page.locator(".hint, .ok-text").allInnerTexts().catch(() => []);
  const busy = errs.some((text) => /timeout|busy/i.test(text));
  record(
    "create_wallet",
    busy ? "INVALID" : "FAIL",
    { user, error: String(e).slice(0, 200), errs, hints: hints.slice(0, 6) },
    busy ? "wallet API blocked while node processes state" : "",
  );
}

// 4. Баланс созданного кошелька
if (!walletReady) {
  record("get_balance", "INVALID", {}, "skipped: wallet was not created");
} else
try {
  await page.getByRole("button", { name: "Баланс", exact: true }).click();
  await page.waitForSelector(".spendable", { timeout: 30000 });
  const values = await page.locator(".spendable, .subbalance").allInnerTexts();
  record("get_balance", values.length > 0 ? "PASS" : "FAIL", { values: values.slice(0, 4) });
} catch (e) {
  record("get_balance", "FAIL", { error: String(e) });
}

// 5. Настройки: чтение и сохранение server_config.json
try {
  await page.locator('.nav-item:has-text("Настройки")').click();
  const area = page.locator("textarea").first();
  await area.waitFor({ timeout: 15000 });
  const text = await area.inputValue();
  JSON.parse(text);
  await page.getByRole("button", { name: "Сохранить" }).click();
  await page.waitForSelector("text=сохранено", { timeout: 15000 });
  record("settings_save", "PASS", { configLen: text.length });
  await shot(page, "settings");
} catch (e) {
  record("settings_save", "FAIL", { error: String(e) });
}

// 6. Логи: хвост лога читается и отображается
try {
  await page.locator('.nav-item:has-text("Логи")').click();
  await page.waitForSelector(".logs", { timeout: 15000 });
  await page
    .waitForFunction(
      () => {
        const el = document.querySelector(".logs");
        return !!el && (el.textContent ?? "").trim().length > 100;
      },
      undefined,
      { timeout: 20000 },
    )
    .catch(() => {});
  const logs = await page.locator(".logs").innerText();
  const errs = await page.locator(".err-text").allInnerTexts().catch(() => []);
  record("logs_tail", logs.trim().length > 100 ? "PASS" : "FAIL", {
    len: logs.trim().length,
    errs,
  });
  await shot(page, "logs");
} catch (e) {
  record("logs_tail", "FAIL", { error: String(e) });
}

// 7. Переключение языка RU → EN
try {
  const selects = page.locator(".chrome select");
  await selects.first().selectOption("en");
  await page.waitForSelector('.nav-item:has-text("Status")', { timeout: 10000 });
  const enNav = await page.locator(".nav-item").first().innerText();
  await selects.first().selectOption("ru");
  await page.waitForSelector('.nav-item:has-text("Статус")', { timeout: 10000 });
  record("i18n_switch", enNav.trim().toLowerCase() === "status" ? "PASS" : "FAIL", { enNav });
  await shot(page, "i18n-en");
} catch (e) {
  record("i18n_switch", "FAIL", { error: String(e) });
}

await browser.close();
console.log(failures === 0 ? "ALL PASS" : `FAILURES: ${failures}`);
process.exit(failures === 0 ? 0 : 1);

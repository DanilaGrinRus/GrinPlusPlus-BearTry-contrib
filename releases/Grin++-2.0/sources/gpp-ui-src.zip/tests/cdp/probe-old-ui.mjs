// Диагностика старого Electron-UI по CDP: консоль, ошибки, DOM.
import { chromium } from "playwright-core";

const url = process.argv[2] ?? "http://127.0.0.1:9333";
const browser = await chromium.connectOverCDP(url);
const page = browser.contexts()[0].pages()[0];

const logs = [];
page.on("console", (m) => logs.push(`[${m.type()}] ${m.text().slice(0, 300)}`));
page.on("pageerror", (e) => logs.push(`[pageerror] ${String(e).slice(0, 300)}`));

await page.waitForTimeout(6000);

const info = await page.evaluate(() => ({
  title: document.title,
  bodyLen: document.body.innerHTML.length,
  rootHtml: (document.getElementById("root")?.innerHTML ?? "").slice(0, 400),
  scripts: Array.from(document.scripts).map((s) => s.src || "inline").slice(0, 8),
  hasRequire: typeof window.require,
  electron: typeof window.electron,
  localStorageKeys: Object.keys(localStorage).slice(0, 10),
}));

console.log(JSON.stringify({ info, logs: logs.slice(-25) }, null, 2));
await browser.close();

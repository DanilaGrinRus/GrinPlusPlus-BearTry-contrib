// Проверка переключения Floonet/Mainnet в UI: сеть, пути, статус.
import { chromium } from "playwright-core";

const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
const page = browser.contexts()[0].pages()[0];
await page.waitForSelector(".app .toolbar", { timeout: 20000 });

const result = {};
const netSelect = page.locator(".toolbar select").nth(1);

await netSelect.selectOption("MAINNET");
await page.waitForTimeout(2500);
result.afterMainnet = {
  select: await netSelect.inputValue(),
  footer: (await page.locator(".statusbar").innerText()).replace(/\s+/g, " ").slice(0, 200),
};
await page.locator('.nav-item[title="статус"], .nav-item[title="Status"], .icon-btn[title="статус"], .icon-btn[title="Status"]').first().click().catch(() => {});
await page.waitForTimeout(2000);
result.statusPageText = (await page.locator(".content").innerText()).replace(/\s+/g, " ").slice(0, 500);

await netSelect.selectOption("FLOONET");
await page.waitForTimeout(2500);
result.afterFloonet = {
  select: await netSelect.inputValue(),
  footer: (await page.locator(".statusbar").innerText()).replace(/\s+/g, " ").slice(0, 200),
  statusPageText: (await page.locator(".content").innerText()).replace(/\s+/g, " ").slice(0, 500),
};

console.log(JSON.stringify(result, null, 2));
await browser.close();

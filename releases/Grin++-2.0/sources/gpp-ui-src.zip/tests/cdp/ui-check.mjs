import { chromium } from "playwright-core";
const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
const page = browser.contexts()[0].pages()[0];
await page.waitForSelector(".app .toolbar", { timeout: 30000 });
const out = "C:\\DHW\\Gplus\\evidence\\ui-tauri-20261110\\cdp";
// Tor page
await page.locator('.icon-btn[title="Tor"]').click();
await page.waitForTimeout(1500);
await page.screenshot({ path: out + "\\ui-check-tor.png" });
// Wallet page: restore form
await page.locator('.icon-btn[title="Wallet"]').click();
await page.waitForTimeout(800);
await page.getByRole("button", { name: /^restore wallet$/i }).click();
await page.waitForTimeout(800);
await page.screenshot({ path: out + "\\ui-check-restore.png" });
console.log("ok");
await browser.close();

# run-smoke.ps1 — запуск Tauri-приложения с remote debugging и прогон CDP-сценариев.
#
# Приложение стартует с WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS=--remote-debugging-port=9222,
# playwright-core подключается по CDP и проходит 7 сценариев.
# Скриншоты и JSONL складываются в evidence/ui-tauri-20261110/cdp/.

param(
    [string]$Project = 'C:\DHW\Gplus\work\gpp-ui-tauri-20261110',
    [int]$Port = 9222,
    [string]$Evidence = 'C:\DHW\Gplus\evidence\ui-tauri-20261110\cdp'
)

$ErrorActionPreference = 'Stop'
$exe = Join-Path $Project 'src-tauri\target\release\grinpp-desktop.exe'
if (-not (Test-Path $exe)) { throw "app binary not found: $exe" }

New-Item -ItemType Directory -Force -Path $Evidence | Out-Null

# чистое состояние
Get-Process grinpp-desktop -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.Id -Force }
Start-Sleep -Seconds 2

$env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS = "--remote-debugging-port=$Port"
$env:GRINPP_TEST_CDP = '1'
$app = Start-Process -FilePath $exe -PassThru `
    -RedirectStandardOutput (Join-Path $Evidence 'app.out.log') `
    -RedirectStandardError (Join-Path $Evidence 'app.err.log')

# ждём CDP-эндпоинт
$deadline = (Get-Date).AddSeconds(60)
$ready = $false
while ((Get-Date) -lt $deadline) {
    try {
        $r = Invoke-WebRequest "http://127.0.0.1:$Port/json/version" -TimeoutSec 3 -UseBasicParsing
        if ($r.StatusCode -eq 200) { $ready = $true; break }
    } catch { }
    Start-Sleep -Milliseconds 500
}
if (-not $ready) {
    Get-Process -Id $app.Id -ErrorAction SilentlyContinue | Stop-Process -Force
    throw "CDP endpoint did not appear on port $Port"
}
Write-Output "cdp ready on $Port"

$node = 'node'
Push-Location $Project
try {
    & $node 'tests\cdp\smoke.mjs' $Evidence "http://127.0.0.1:$Port"
    $code = $LASTEXITCODE
} finally {
    Pop-Location
    Get-Process -Id $app.Id -ErrorAction SilentlyContinue | Stop-Process -Force
    Remove-Item Env:WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS -ErrorAction SilentlyContinue
    Remove-Item Env:GRINPP_TEST_CDP -ErrorAction SilentlyContinue
}

Write-Output "smoke exit=$code evidence=$Evidence"
exit $code

import { chromium } from "playwright-core";
const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
const page = browser.contexts()[0].pages()[0];
await page.waitForSelector(".app .toolbar", { timeout: 20000 });
const out = "C:\\DHW\\Gplus\\evidence\\ui-tauri-20261110\\cdp";
await page.locator('.icon-btn[title="Логи"]').click();
await page.waitForTimeout(1200);
await page.getByRole("button", { name: /^Этапы$/ }).click();
await page.waitForTimeout(4000);
const rows = await page.locator(".stage-table tbody tr").count();
await page.screenshot({ path: out + "\\ui-list-stages.png" });
console.log("stage rows:", rows);
if (rows > 0) {
  const first = await page.locator(".stage-table tbody tr").first().innerText();
  console.log("first stage:", first.replace(/\t/g, " | "));
}
await browser.close();

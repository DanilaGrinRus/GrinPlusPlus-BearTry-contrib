import { chromium } from "playwright-core";
const b = await chromium.connectOverCDP("http://127.0.0.1:9222");
const p = b.contexts()[0].pages()[0];
await p.waitForSelector(".app .toolbar", { timeout: 20000 });
console.log("title:", await p.title());
console.log("body:", (await p.locator("body").innerText()).slice(0, 500));
await p.screenshot({ path: "C:\\DHW\\Gplus\\evidence\\gplus-2.0.0-20261111\\ui-mainnet-20261112.png" });
await b.close();

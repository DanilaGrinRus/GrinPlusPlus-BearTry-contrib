# Grin++ Desktop (Tauri 2) — отдельная реализация UI

Замена Electron-оболочки Grin++ 1.2.8. Бэкенд не меняется: вся связь с продуктом —
HTTP JSON-RPC ноды (`/v1`, `/v2/owner`, `/v2/foreign`), поэтому C++-код остаётся как есть,
а webview не получает прямого доступа к файлам и процессам.

## Стек

- **Ядро:** Rust, Tauri 2 (WebView2 на Windows).
- **Интерфейс:** React 18 + TypeScript + Vite (без CRA/craco/node-sass).
- **Границы:** webview → `invoke()` → команды ядра → HTTP к ноде.

## Что уже работает

| Команда / экран | Поведение |
|---|---|
| `app_paths` | где лежит `GrinNode.exe`, каталог данных, порты REST/wallet из `server_config.json` |
| `start_node` / `stop_node` / `node_running` | запуск ноды как дочернего процесса с **портативным профилем** |
| `node_health` / `node_status` | `/v1/health`, `/v1/status` (опрос каждые 5 с) |
| `read_log_tail` | хвост `<данные>\LOGS\Node.log` |
| `read_net_config` / `save_net_config` | `server_config.json` сети (просмотр/правка) |
| `api_secret_present` | наличие `.api_secret` (сам секрет в webview не отдаётся) |
| `wallet_rpc` | прокси `/v2` с `Authorization: Bearer <api_secret>`: `create_wallet`, `restore_wallet`, `login`, `list_wallets`, `get_balance`, `get_slatepack_address`, `get_new_slatepack_address`, `estimate_fee`, `send`, `receive`, `finalize`, `list_txs`, `cancel_tx`, `repost_tx` |

Экраны: **Статус** (нода, синк, пути), **Кошелёк** (создание/восстановление/вход/список/баланс/seed),
**Отправка** (S1 → S3: оценка комиссии, send, slatepack, finalize ответного), **Получение**
(адрес, новый адрес, приём S1 → ответный S2), **История** (list_txs, отмена/повтор), **Tor** (мосты Moat+CAPTCHA, snowflake, torrc, retry), **Логи**,
**Настройки**.

Формы вызовов взяты из зафиксированного контракта и live-прогонов: `fee_base = 1000000`,
`selection_strategy = 'SMALLEST'`, `change_outputs = 1`, `post_tx = false`; суммы считаются в
нано-GRIN через `BigInt` (без float).

### Портативное правило (важно)

Данные ноды создаются **в папке с `GrinNode.exe`** (`<папка ноды>\.GrinPP`), а не в профиле
пользователя. На Windows `FileUtil::GetHomeDirectory()` читает `HOMEDRIVE` + `HOMEPATH`, поэтому
ядро выставляет их явно, а также `USERPROFILE`, `HOME`, `APPDATA`, `LOCALAPPDATA`, `TMP`, `TEMP`.
Это закреплено тестом `child_env_pins_homedrive_and_homepath_to_the_node_folder`.

## Сборка

```powershell
# 1. зависимости фронтенда (pnpm; глобальный npm в этой системе повреждён)
node <pnpm.mjs> install --store-dir .pnpm-store

# 2. фронтенд
$env:ESBUILD_BINARY_PATH = "<...>\@esbuild\win32-x64\esbuild.exe"
node node_modules\vite\bin\vite.js build     # -> dist/

# 3. ядро (запускать из C:\ — иначе cargo подхватит офлайн-конфиг C:\DHW\.cargo)
cd C:\
cargo build --release --manifest-path C:\DHW\Gplus\work\gpp-ui-tauri-20261110\src-tauri\Cargo.toml
```

Бинарник: `src-tauri\target\release\grinpp-desktop.exe` (~11,5 МБ; для сравнения Electron-сборка ~100+ МБ).

Тесты ядра: `cargo test --release --manifest-path ...` — 3 теста (пути, порты, env).

## Ограничения текущей среды

- Профиль WebView2 по умолчанию создаётся **рядом с приложением** (`<exe_dir>\.webview2`):
  запись в `%LOCALAPPDATA%` в ограниченных окружениях запрещена (симптом —
  `Failed to setup app: Отказано в доступе`). Проверено: окно «Grin++» открывается.
- `bundle.active = false`: установщик пока не собирается (нужны иконки размеров и WiX/NSIS).
- Icons: `src-tauri/icons/icon.ico` + `icon.png` сгенерированы скриптом `make-icon.py`.

## Что дальше (паритет с Electron 1.2.8)

1. Смена пароля и удаление кошелька (с секретом), отдельный экран seed.
2. i18n (en/ru), тема, трей и авто-обновление.
3. Сборка установщика (WiX/NSIS) и подпись; иконки в бандле.

## Live-проверка ядра

```powershell
# против уже запущенной ноды (не стартует/не гасит её)
.\src-tauri\target\release\live_cycle.exe

# либо с самостоятельным запуском ноды
.\src-tauri\target\release\live_cycle.exe --start
```

Печатает JSONL по кейсам; exit 1, если хоть один FAIL. Текущий результат — 15/15 PASS.

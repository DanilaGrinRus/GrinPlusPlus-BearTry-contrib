$ErrorActionPreference = 'Stop'
$nl = "`r`n"
$f = 'C:\DHW\Gplus\work\gpp-ui-tauri-20261110\src\App.tsx'
$t = [System.IO.File]::ReadAllText($f)

# 1) PaymentsPage: accept net, add Tor status
$old = '  onSession,' + $nl + '  initialTab,' + $nl + '}: {' + $nl + '  enabled: boolean;' + $nl + '  call: Call;' + $nl + '  session: Session | null;' + $nl + '  onSession: (s: Session | null) => void;' + $nl + '  initialTab: "create" | "receive" | "finalize";' + $nl + '}) {' + $nl + '  const [tab, setTab] = useState<"create" | "receive" | "finalize">(initialTab);' + $nl + '  useEffect(() => setTab(initialTab), [initialTab]);'
$new = '  onSession,' + $nl + '  initialTab,' + $nl + '  net,' + $nl + '}: {' + $nl + '  enabled: boolean;' + $nl + '  call: Call;' + $nl + '  session: Session | null;' + $nl + '  onSession: (s: Session | null) => void;' + $nl + '  initialTab: "create" | "receive" | "finalize";' + $nl + '  net: Net;' + $nl + '}) {' + $nl + '  const [tab, setTab] = useState<"create" | "receive" | "finalize">(initialTab);' + $nl + '  const [torUp, setTorUp] = useState<boolean | null>(null);' + $nl + '  useEffect(() => setTab(initialTab), [initialTab]);' + $nl + '  useEffect(() => {' + $nl + '    if (!enabled) {' + $nl + '      setTorUp(null);' + $nl + '      return;' + $nl + '    }' + $nl + '    let alive = true;' + $nl + '    const tick = async () => {' + $nl + '      try {' + $nl + '        const up = await torRunning(net);' + $nl + '        if (alive) setTorUp(up);' + $nl + '      } catch {' + $nl + '        /* ignore */' + $nl + '      }' + $nl + '    };' + $nl + '    tick();' + $nl + '    const timer = window.setInterval(tick, 5000);' + $nl + '    return () => {' + $nl + '      alive = false;' + $nl + '      window.clearInterval(timer);' + $nl + '    };' + $nl + '  }, [enabled, net]);'
if (-not $t.Contains($old)) { throw 'payments signature anchor missing' }
$t = $t.Replace($old, $new)

# badge row above tabs
$old = '      <div className="tabs" style={{ marginBottom: 14 }}>' + $nl + '        {[["create", "1. Создать (S1)"], ["receive", "2. Принять (S2)"], ["finalize", "3. Завершить (S3)"]].map(([id, label]) => ('
$new = '      <div className="row" style={{ marginBottom: 10, alignItems: "center" }}>' + $nl +
'        <span className={`badge ${torUp === null ? "wait" : torUp ? "ok" : "bad"}`}>' + $nl +
'          {!enabled ? "нода не запущена" : torUp === null ? "Tor: проверяю…" : torUp ? "Tor работает" : "Tor не работает"}' + $nl +
'        </span>' + $nl +
'        {enabled && torUp === false && (' + $nl +
'          <span className="hint">Tor недоступен: slatepack можно передавать вручную (скопировать S1/S2). Для прямой доставки включите мосты на странице Tor.</span>' + $nl +
'        )}' + $nl +
'      </div>' + $nl + $old
if (-not $t.Contains($old)) { throw 'payments tabs anchor missing' }
$t = $t.Replace($old, $new)

# route net prop
$t = $t.Replace('<PaymentsPage enabled={nodeUp} call={call} session={session} onSession={setSession} initialTab="create" />',
                '<PaymentsPage enabled={nodeUp} call={call} session={session} onSession={setSession} initialTab="create" net={net} />')
$t = $t.Replace('<PaymentsPage enabled={nodeUp} call={call} session={session} onSession={setSession} initialTab="receive" />',
                '<PaymentsPage enabled={nodeUp} call={call} session={session} onSession={setSession} initialTab="receive" net={net} />')

# 2) Status page: paths under "Для отладки"
$startMarker = '      <div className="panel">' + $nl + '        <h2>{t("status.paths")}</h2>'
$start = $t.IndexOf($startMarker)
if ($start -lt 0) { throw 'status paths panel start missing' }
$endMarker = '        </div>' + $nl + '      </div>' + $nl + '    </>' + $nl + '  );' + $nl + '}'
$end = $t.IndexOf($endMarker, $start)
if ($end -lt 0) { throw 'status paths panel end missing' }
$panel = $t.Substring($start, $end - $start + ('        </div>' + $nl + '      </div>').Length)
$wrapped = '      <details>' + $nl + '        <summary className="hint" style={{ cursor: "pointer", padding: "4px 0" }}>Для отладки: расположение данных</summary>' + $nl + $panel + $nl + '      </details>'
$t = $t.Substring(0, $start) + $wrapped + $t.Substring($end + ('        </div>' + $nl + '      </div>').Length)

[System.IO.File]::WriteAllText($f, $t, (New-Object System.Text.UTF8Encoding($false)))
Write-Output ('P2 app patched: torBadge=' + $t.Contains('Tor недоступен: slatepack') + ' debugDetails=' + $t.Contains('Для отладки: расположение данных'))

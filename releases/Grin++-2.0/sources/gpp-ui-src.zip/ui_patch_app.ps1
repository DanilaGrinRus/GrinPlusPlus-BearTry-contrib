$ErrorActionPreference = 'Stop'
$nl = "`r`n"
$f = 'C:\DHW\Gplus\work\gpp-ui-tauri-20261110\src\App.tsx'
$t = [System.IO.File]::ReadAllText($f)

# 1) state: seed words (default 24)
$anchor = '  const [seed, setSeed] = useState<string | null>(null);'
$add = $anchor + $nl + '  const [seedWords, setSeedWords] = useState(24);'
if (-not $t.Contains($anchor)) { throw 'seed state anchor missing' }
$t = $t.Replace($anchor, $add)

# 2) create_wallet uses selected word count
$t = $t.Replace('const result = await call("create_wallet", { username, password, num_seed_words: 12 });',
                'const result = await call("create_wallet", { username, password, num_seed_words: seedWords });')

# 3) restore validates word count
$anchor = '  const onRestore = async () => {' + $nl + '    const result = await call("restore_wallet", { username, password, wallet_seed: seed ?? "" });'
$add = '  const onRestore = async () => {' + $nl + '    const words = (seed ?? "").trim().split(/\s+/).filter(Boolean);' + $nl + '    if (words.length !== seedWords) {' + $nl + '      setMessage(`В сиде должно быть ${seedWords} слов, вставлено ${words.length}`);' + $nl + '      return;' + $nl + '    }' + $nl + '    const result = await call("restore_wallet", { username, password, wallet_seed: seed ?? "" });'
if (-not $t.Contains($anchor)) { throw 'restore anchor missing' }
$t = $t.Replace($anchor, $add)

# 4) restore button must not be disabled by network state
$t = $t.Replace('<button className="welcome-link" onClick={() => setMode("restore")} disabled={!enabled}>',
                '<button className="welcome-link" onClick={() => setMode("restore")}>')
$t = $t.Replace('{mode === "restore" && !enabled && <div className="hint">Restore can not start until the Node has been fully synced.</div>}',
                '{!enabled && <div className="hint">Нода не запущена: создать/восстановить кошелёк можно, но синхронизация и операции потребуют запущенной ноды.</div>}')

# 5) word-count selector + seed placeholder in the form
$anchor = '            {mode === "restore" && (' + $nl + '              <textarea'
$add = '            {(mode === "create" || mode === "restore") && (' + $nl + '              <div className="row" style={{ marginBottom: 8 }}>' + $nl + '                <span className="hint">Слов в сиде</span>' + $nl + '                <select value={seedWords} onChange={(e) => setSeedWords(Number(e.target.value))}>' + $nl + '                  <option value={12}>12</option>' + $nl + '                  <option value={18}>18</option>' + $nl + '                  <option value={24}>24</option>' + $nl + '                </select>' + $nl + '              </div>' + $nl + '            )}' + $nl + $anchor
if (-not $t.Contains($anchor)) { throw 'restore form anchor missing' }
$t = $t.Replace($anchor, $add)
$t = $t.Replace('                placeholder="seed"', '                placeholder={`seed (${seedWords} слов)`}')

# 6) UI log capture: import uiLog
$anchor = 'import {'
# find the api import line and append uiLog to it instead: locate first "from \"./api\";"
$apiIdx = $t.IndexOf('from "./api";')
if ($apiIdx -lt 0) { throw 'api import missing' }
$lineStart = $t.LastIndexOf('import ', $apiIdx)
$importLine = $t.Substring($lineStart, $apiIdx + 'from "./api";'.Length - $lineStart)
$newImport = $importLine
$t = $t.Replace("  nodeStatus,", "  nodeStatus," + [Environment]::NewLine + "  uiLog,")
$t = $t.Substring(0, $lineStart) + $newImport + $t.Substring($lineStart + $importLine.Length)

# 7) install error hooks inside App (after a known effect in App component: use "useEffect(() => {" first occurrence in App)
$anchor = '  useEffect(() => {' + $nl + '    let alive = true;'
$hook = '  useEffect(() => {' + $nl + '    const logError = (level: string, message: string) => {' + $nl + '      uiLog(net, level, message).catch(() => undefined);' + $nl + '    };' + $nl + '    const onError = (e: ErrorEvent) => logError("error", `${e.message} @ ${e.filename}:${e.lineno}`);' + $nl + '    const onRejection = (e: PromiseRejectionEvent) => logError("error", `unhandledrejection: ${String(e.reason)}`);' + $nl + '    const originalConsoleError = console.error;' + $nl + '    console.error = (...args: unknown[]) => {' + $nl + '      logError("error", args.map((a) => String(a)).join(" "));' + $nl + '      originalConsoleError(...args);' + $nl + '    };' + $nl + '    window.addEventListener("error", onError);' + $nl + '    window.addEventListener("unhandledrejection", onRejection);' + $nl + '    return () => {' + $nl + '      window.removeEventListener("error", onError);' + $nl + '      window.removeEventListener("unhandledrejection", onRejection);' + $nl + '      console.error = originalConsoleError;' + $nl + '    };' + $nl + '  }, [net]);' + $nl + $nl + $anchor
if ($t.Contains('    let alive = true;')) { $t = $t.Replace($anchor, $hook) } else { Write-Output 'WARN: App effect anchor not found; ui log hooks not installed' }

[System.IO.File]::WriteAllText($f, $t, (New-Object System.Text.UTF8Encoding($false)))
Write-Output ('App.tsx patched: seedWords=' + $t.Contains('seedWords') + ' uiLog=' + $t.Contains('uiLog(net'))

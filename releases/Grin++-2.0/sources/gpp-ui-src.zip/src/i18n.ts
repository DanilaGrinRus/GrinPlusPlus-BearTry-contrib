// i18n: русский/английский. Модульный state + t(key), чтобы не протаскивать
// перевод через пропсы каждого компонента.

export type Lang = "ru" | "en";

type Dict = Record<string, { ru: string; en: string }>;

const messages: Dict = {
  "nav.status": { ru: "Статус", en: "Status" },
  "nav.wallet": { ru: "Кошелёк", en: "Wallet" },
  "nav.send": { ru: "Отправка", en: "Send" },
  "nav.receive": { ru: "Получение", en: "Receive" },
  "nav.payments": { ru: "Платежи", en: "Payments" },
  "nav.history": { ru: "История", en: "History" },
  "nav.tor": { ru: "Tor", en: "Tor" },
  "nav.logs": { ru: "Логи", en: "Logs" },
  "nav.settings": { ru: "Настройки", en: "Settings" },

  "node.start": { ru: "Запустить", en: "Start" },
  "node.stop": { ru: "Стоп", en: "Stop" },
  "node.restart": { ru: "Перезапустить ноду", en: "Restart node" },
  "node.tor": { ru: "Использовать Tor", en: "Use Tor" },
  "node.torSaved": { ru: "настройка сохранена, перезапустите ноду", en: "saved, restart the node to apply" },
  "node.torDisabled": { ru: "Tor выключен в конфиге ноды.", en: "Tor is disabled in the node config." },
  "node.ownHint": { ru: "Нода запущена этим окном: стоп/рестарт доступны.", en: "Node was started by this window: stop/restart available." },
  "node.external": { ru: "Нода запущена вне этого окна — остановить её отсюда нельзя.", en: "Node runs outside this window; it cannot be stopped here." },
  "node.netHint": { ru: "Переключить сеть (нода будет перезапущена)", en: "Switch network (the node will be restarted)" },
  "node.logout": { ru: "Выйти", en: "Log out" },
  "node.logoutAll": { ru: "Выйти везде", en: "Log out everywhere" },

  "top.height": { ru: "высота", en: "height" },
  "top.peers": { ru: "пиры", en: "peers" },
  "top.network": { ru: "сеть", en: "network" },
  "top.notRunning": { ru: "нода не запущена", en: "node is not running" },
  "top.noApi": { ru: "нет ответа API", en: "no API response" },
  "top.apiSecret": { ru: "api_secret", en: "api_secret" },

  "status.node": { ru: "Нода", en: "Node" },
  "status.paths": { ru: "Расположение данных", en: "Data location" },
  "status.process": { ru: "процесс", en: "process" },
  "status.running": { ru: "запущена", en: "running" },
  "status.stopped": { ru: "остановлена", en: "stopped" },
  "status.headers": { ru: "заголовки", en: "headers" },
  "status.blocks": { ru: "блоки", en: "blocks" },
  "status.dataHint": {
    ru: "Всё, что создаёт нода, лежит в её папке:",
    en: "Everything the node creates lives in its folder:",
  },
  "status.netDir": { ru: "каталог сети", en: "network folder" },
  "status.restPort": { ru: "REST порт", en: "REST port" },
  "status.walletPort": { ru: "wallet порт", en: "wallet port" },

  "wallet.title": { ru: "Кошелёк", en: "Wallet" },
  "wallet.create": { ru: "Создать кошелёк", en: "Create Wallet" },
  "wallet.restore": { ru: "Восстановить кошелёк", en: "Restore Wallet" },
  "wallet.login": { ru: "Войти", en: "Log in" },
  "wallet.list": { ru: "Список", en: "List" },
  "wallet.balance": { ru: "Баланс", en: "Balance" },
  "wallet.spendable": { ru: "Spendable ₲", en: "Spendable ₲" },
  "wallet.seedSavedHint": { ru: "Сохраните seed: он больше не будет показан, без него кошелёк не восстановить.", en: "Save the seed: it will not be shown again and cannot be recovered without it." },
  "wallet.address": { ru: "Адрес", en: "Address" },
  "wallet.changePassword": { ru: "Сменить пароль", en: "Change password" },
  "wallet.deleteWallet": { ru: "Удалить кошелёк", en: "Delete wallet" },
  "wallet.wallets": { ru: "Кошельки", en: "Wallets" },
  "wallet.seedOnce": { ru: "seed (показывается один раз)", en: "seed (shown once)" },
  "wallet.restoreWithSeed": { ru: "Восстановить этим seed", en: "Restore with this seed" },
  "wallet.hide": { ru: "Скрыть", en: "Hide" },
  "wallet.startNodeFirst": { ru: "Сначала запустите ноду.", en: "Start the node first." },
  "wallet.loginFirst": { ru: "Войдите в кошелёк.", en: "Log in to the wallet." },
  "wallet.newPassword": { ru: "новый пароль", en: "new password" },
  "wallet.created": { ru: "кошелёк создан — сохраните seed", en: "wallet created — save the seed" },
  "wallet.restored": { ru: "кошелёк восстановлен", en: "wallet restored" },
  "wallet.loggedIn": { ru: "вход выполнен", en: "logged in" },
  "wallet.passwordChanged": { ru: "пароль изменён", en: "password changed" },
  "wallet.deleted": { ru: "кошелёк удалён", en: "wallet deleted" },
  "wallet.sessionsClosed": { ru: "все сессии закрыты", en: "all sessions closed" },
  "wallet.confirmDelete": { ru: "Нажмите «Удалить кошелёк» ещё раз — действие необратимо", en: "Press Delete wallet again — this cannot be undone" },
  "wallet.confirmLogout": { ru: "Нажмите «Выйти везде» ещё раз, чтобы закрыть все сессии", en: "Press Log out everywhere again to close all sessions" },

  "send.title": { ru: "Отправка (Slatepack S1 → S3)", en: "Send (Slatepack S1 → S3)" },
  "send.addressPlaceholder": { ru: "slatepack-адрес получателя", en: "recipient slatepack address" },
  "send.amountPlaceholder": { ru: "сумма, GRIN", en: "amount, GRIN" },
  "send.estimate": { ru: "Оценить комиссию", en: "Estimate fee" },
  "send.send": { ru: "Отправить", en: "Send" },
  "send.fee": { ru: "комиссия", en: "fee" },
  "send.slatepackOut": { ru: "S1: slatepack для получателя", en: "S1: slatepack for the receiver" },
  "send.finalizeBlock": { ru: "S3: финализация ответного slatepack", en: "S3: finalize the response slatepack" },
  "send.finalize": { ru: "Финализировать", en: "Finalize" },
  "send.responsePlaceholder": { ru: "вставьте ответный slatepack от получателя (S2)", en: "paste the receiver response slatepack (S2)" },

  "receive.myAddress": { ru: "Мой адрес", en: "My address" },
  "receive.refresh": { ru: "Обновить", en: "Refresh" },
  "receive.newAddress": { ru: "Новый адрес", en: "New address" },
  "receive.incoming": { ru: "S2: принять входящий slatepack", en: "S2: accept an incoming slatepack" },
  "receive.accept": { ru: "Принять", en: "Receive" },
  "receive.responseOut": {
    ru: "Ответный slatepack (вернуть отправителю)",
    en: "Response slatepack (send back to the sender)",
  },
  "receive.incomingPlaceholder": { ru: "вставьте slatepack от отправителя (S1)", en: "paste the sender slatepack (S1)" },

  "history.title": { ru: "Transactions", en: "Transactions" },
  "history.id": { ru: "id", en: "id" },
  "history.type": { ru: "тип", en: "type" },
  "history.state": { ru: "статус", en: "state" },
  "history.amount": { ru: "сумма", en: "amount" },
  "history.actions": { ru: "действия", en: "actions" },
  "history.cancel": { ru: "Отменить", en: "Cancel" },
  "history.repost": { ru: "Повторить", en: "Repost" },

  "common.copy": { ru: "Копировать", en: "Copy" },
  "common.copied": { ru: "скопировано", en: "copied" },
  "common.copyUnavailable": { ru: "копирование недоступно", en: "clipboard unavailable" },
  "common.empty": { ru: "Нет транзакций.", en: "There are no transactions to display." },
  "common.noData": { ru: "нет данных", en: "no data" },
  "common.save": { ru: "Сохранить", en: "Save" },
  "common.openDataDir": { ru: "Открыть папку данных", en: "Open data folder" },
  "common.openInExplorer": { ru: "Открыть в проводнике", en: "Show in folder" },
  "common.yes": { ru: "есть", en: "present" },
  "common.no": { ru: "нет", en: "absent" },
  "common.status": { ru: "статус", en: "status" },
  "common.type": { ru: "тип", en: "type" },

  "tor.title": { ru: "Мосты Tor", en: "Tor bridges" },
  "tor.auto": { ru: "Получить мосты автоматически", en: "Fetch bridges automatically" },
  "tor.snowflake": { ru: "Включить snowflake", en: "Enable snowflake" },
  "common.refresh": { ru: "Обновить", en: "Refresh" },
  "common.open": { ru: "Открыть", en: "Open" },
  "common.auto": { ru: "авто", en: "auto" },
  "common.export": { ru: "Экспорт", en: "Export" },
  "settings.saveRaw": { ru: "Сохранить raw", en: "Save raw" },
  "settings.resync": { ru: "Пересинхронизировать ноду", en: "Resync node" },
  "tor.retry": { ru: "Перезапустить Tor", en: "Restart Tor" },
  "tor.captcha": { ru: "CAPTCHA BridgeDB", en: "BridgeDB CAPTCHA" },
  "tor.offered": { ru: "Предложенные obfs4-мосты", en: "Offered obfs4 bridges" },
  "tor.apply": { ru: "Применить", en: "Apply" },
  "tor.current": { ru: "Текущий torrc", en: "Current torrc" },
  "tor.gotBridges": { ru: "BridgeDB отдал obfs4-мостов:", en: "BridgeDB returned obfs4 bridges:" },
  "tor.needCaptcha": { ru: "нужно решить CAPTCHA", en: "solve the CAPTCHA" },
  "tor.received": { ru: "получено мостов:", en: "bridges received:" },
  "tor.applied": { ru: "применено", en: "applied" },
  "tor.snowflakeFromMap": { ru: "snowflake из карты", en: "snowflake from the map" },
  "tor.captchaAnswer": { ru: "ответ с картинки", en: "answer from the image" },
  "tor.check": { ru: "Проверить", en: "Check" },
  "tor.cancel": { ru: "Отмена", en: "Cancel" },
  "tor.bridgesCount": { ru: "мостов", en: "bridges" },

  "logs.title": { ru: "Логи ноды", en: "Node logs" },
  "logs.auto": { ru: "авто", en: "auto" },
  "logs.noData": { ru: "нет данных", en: "no data" },

  "settings.title": { ru: "server_config.json", en: "server_config.json" },
  "settings.saved": { ru: "сохранено", en: "saved" },
  "settings.error": { ru: "ошибка", en: "error" },
  "settings.hint": { ru: "Запись идёт в", en: "Written to" },
  "settings.hintApplied": {
    ru: "применяется к следующему запуску ноды.",
    en: "applies to the next node start.",
  },
};

let current: Lang = "ru";

export const getLang = (): Lang => current;
export const setLang = (lang: Lang): void => {
  current = lang;
  try {
    localStorage.setItem("grinpp.lang", lang);
  } catch {
    /* localStorage может быть недоступен */
  }
};

export const t = (key: string): string => {
  const entry = messages[key];
  if (!entry) return key;
  return entry[current];
};

export const availableLangs: Lang[] = ["ru", "en"];

import { useCallback, useEffect, useMemo, useState } from "react";
import { logTail, logTailNamed, openLogFile, readConfig, resyncNode, saveConfig } from "./api";

type Net = "FLOONET" | "MAINNET";



/* ---------- Console (логи + состояние ноды), как в оригинале ---------- */

export function ConsolePage({ net }: { net: Net }) {
  const [tab, setTab] = useState<"node" | "wallet" | "ui">("node");
  const [lines, setLines] = useState<string[]>([]);
  const [stageLines, setStageLines] = useState<string[]>([]);
  const [auto, setAuto] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<"all" | "errors" | "stage">("all");
  const [count, setCount] = useState(100);

  const file = tab === "node" ? "Node.log" : tab === "wallet" ? "Wallet.log" : "ui.log";

  useEffect(() => {
    if (filter !== "stage") return;
    logTailNamed(net, file, 200000)
      .then(setStageLines)
      .catch(() => setStageLines([]));
  }, [filter, net, file]);

  const refresh = useCallback(async () => {
    try {
      setLines(await logTailNamed(net, file, count));
      setError(null);
    } catch (e) {
      setError(String(e));
      if (tab === "node") {
        try {
          setLines(await logTail(net, count));
        } catch {
          /* ignore */
        }
      }
    }
  }, [net, file, tab, count]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  useEffect(() => {
    if (!auto) return;
    const timer = window.setInterval(refresh, 4000);
    return () => window.clearInterval(timer);
  }, [auto, refresh]);

  const filters = useMemo(() => {
    if (tab === "node") {
      return [
        ["all", "All"],
        ["errors", "Errors"],
        ["stage", "Этапы"],
      ] as const;
    }
    if (tab === "wallet") {
      return [
        ["all", "All"],
        ["errors", "Errors"],
      ] as const;
    }
    return [["all", "All"]] as const;
  }, [tab]);

  useEffect(() => {
    if (!filters.some(([id]) => id === filter)) setFilter("all");
  }, [filters, filter]);

  const filtered = useMemo(() => {
    const errors = /error|failed|exception|critical|fatal/i;
    const stage = /(sync|pibd|header|block height|progress|stage|activation)/i;
    if (filter === "errors") return lines.filter((line) => errors.test(line));
    if (filter === "stage") return lines.filter((line) => stage.test(line));
    return lines;
  }, [lines, filter]);

  type StageRow = { ts: string; name: string; ms: number; outcome: string };
  const stageRows = useMemo<StageRow[]>(() => {
    if (filter !== "stage") return [];
    const re = /startup_timing name=(\S+) duration_ms=(\d+) outcome=(\S+)/;
    const rows: StageRow[] = [];
    for (const line of stageLines) {
      const m = line.match(re);
      if (!m) continue;
      const ts = line.match(/^\[([^\]]+)\]/)?.[1] ?? "";
      rows.push({ ts, name: m[1], ms: Number(m[2]), outcome: m[3] });
    }
    return rows.slice(-count);
  }, [stageLines, filter, count]);


  return (
    <div>
      <div className="k">Logs</div>
      <div className="tabs" style={{ margin: "8px 0 6px" }}>
        {[
          ["node", "Node"],
          ["wallet", "Wallet"],
          ["ui", "UI"],
        ].map(([id, label]) => (
          <button
            key={id}
            className={`tab ${tab === id ? "active" : ""}`}
            onClick={() => setTab(id as "node" | "wallet" | "ui")}
          >
            {label}
          </button>
        ))}
      </div>
      <div className="tabs" style={{ margin: "0 0 12px" }}>
        {filters.map(([id, label]) => (
          <button
            key={id}
            className={`tab ${filter === id ? "active" : ""}`}
            onClick={() => setFilter(id as "all" | "errors" | "stage")}
          >
            {label}
          </button>
        ))}
        <span className="chrome-spacer" />
        <label className="hint">
          последние{" "}
          <select value={count} onChange={(e) => setCount(Number(e.target.value))}>
            <option value={100}>100</option>
            <option value={300}>300</option>
            <option value={1000}>1000</option>
          </select>
        </label>
        <button className="ghost" onClick={refresh}>
          обновить
        </button>
        <button className="ghost" onClick={() => openLogFile(net)}>
          открыть папку логов
        </button>
        <label className="hint">
          <input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} /> авто
        </label>
      </div>
      {error && <div className="hint">{file}: {error}</div>}
      {filter === "stage" ? (
        stageRows.length === 0 ? (
          <div className="hint">В выбранных строках нет записей startup_timing.</div>
        ) : (
          <table className="stage-table">
            <thead><tr><th>время</th><th>этап</th><th>длительность</th><th>итог</th></tr></thead>
            <tbody>
              {stageRows.map((row, index) => (
                <tr key={`${row.ts}-${row.name}-${index}`}>
                  <td>{row.ts}</td>
                  <td>{row.name}</td>
                  <td>{(row.ms / 1000).toFixed(1)} с</td>
                  <td className={row.outcome === "success" ? "ok-text" : "bad-text"}>{row.outcome}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )
      ) : (
        <div className="logs">{filtered.slice(-count).join("\n") || "—"}</div>
      )}

    </div>
  );
}

/* ---------- Settings: Node / P2P / Tor, как в оригинале ---------- */

export function SettingsPage({ net, nodeUp }: { net: Net; nodeUp: boolean }) {
  const [config, setConfig] = useState<Record<string, unknown> | null>(null);
  const [raw, setRaw] = useState("");
  const [message, setMessage] = useState<string | null>(null);

  const p2p = useMemo(() => (config?.P2P as Record<string, unknown> | undefined) ?? {}, [config]);
  const server = useMemo(() => (config?.SERVER as Record<string, unknown> | undefined) ?? {}, [config]);
  const [walletPortDraft, setWalletPortDraft] = useState("");

  useEffect(() => {
    setWalletPortDraft(String(server.OWNER_API_PORT ?? 3421));
  }, [server]);
  const wallet = useMemo(() => (config?.WALLET as Record<string, unknown> | undefined) ?? {}, [config]);

  useEffect(() => {
    (async () => {
      const cfg = await readConfig(net);
      setConfig(cfg);
      setRaw(JSON.stringify(cfg, null, 2));
    })();
  }, [net]);

  const save = async (next: Record<string, unknown>) => {
    try {
      await saveConfig(net, next);
      setConfig(next);
      setRaw(JSON.stringify(next, null, 2));
      setMessage("saved");
    } catch (e) {
      setMessage(String(e));
    }
  };

  const updateP2P = (patch: Record<string, unknown>) => {
    if (!config) return;
    const next = { ...config, P2P: { ...(config.P2P as Record<string, unknown>), ...patch } };
    save(next);
  };

  const updateWallet = (patch: Record<string, unknown>) => {
    if (!config) return;
    const next = { ...config, WALLET: { ...(config.WALLET as Record<string, unknown>), ...patch } };
    save(next);
  };

  const updateServer = (patch: Record<string, unknown>) => {
    if (!config) return;
    const next = { ...config, SERVER: { ...(config.SERVER as Record<string, unknown>), ...patch } };
    save(next);
  };

  const confirmations = Number(wallet.MIN_CONFIRMATIONS ?? 10);

  return (
    <div>
      <div className="settings-grid">
        <div className="panel">
          <div className="k">Node</div>
          <div className="row" style={{ marginTop: 10 }}>
            <div className="field">
              <span className="hint">Outbounds</span>
              <input
                type="number"
                value={String(p2p.MAX_PEERS ?? 10)}
                onChange={(e) => updateP2P({ MAX_PEERS: Number(e.target.value) })}
              />
            </div>
            <div className="field">
              <span className="hint">Inbounds</span>
              <input
                type="number"
                value={String(p2p.MIN_PEERS ?? 50)}
                onChange={(e) => updateP2P({ MIN_PEERS: Number(e.target.value) })}
              />
            </div>
          </div>
          <div className="hint" style={{ marginTop: 14 }}>Confirmations</div>
          <div className="row" style={{ marginTop: 6 }}>
            <input
              type="range"
              min={3}
              max={30}
              value={confirmations}
              onChange={(e) => updateWallet({ MIN_CONFIRMATIONS: Number(e.target.value) })}
            />
            <span>{confirmations}</span>
          </div>

          <div className="hint" style={{ marginTop: 16 }}>Wallet API (/v2)</div>
          <div className="row" style={{ marginTop: 6, alignItems: "center" }}>
            <span className="badge">текущий порт: {String(server.OWNER_API_PORT ?? 3421)}</span>
            <a className="hint" href="#raw-config" style={{ textDecoration: "underline" }}>
              где это в server_config.json →
            </a>
          </div>
          <div className="hint" style={{ marginTop: 6 }}>
            Локальный JSON-RPC API кошелька (используется этим приложением). По умолчанию 3421.
            Меняйте, только если порт занят другой программой. После сохранения перезапустите ноду —
            до перезапуска кошелёк в UI будет недоступен.
          </div>
          <div className="row" style={{ marginTop: 6 }}>
            <input
              type="number"
              min={1}
              max={65535}
              placeholder="3421"
              value={walletPortDraft}
              onChange={(e) => setWalletPortDraft(e.target.value)}
            />
            <button
              className="primary"
              disabled={!walletPortDraft || Number(walletPortDraft) === Number(server.OWNER_API_PORT ?? 3421)}
              onClick={() => updateServer({ OWNER_API_PORT: Number(walletPortDraft) })}
            >
              Применить
            </button>
            <button className="ghost" onClick={() => { setWalletPortDraft("3421"); updateServer({ OWNER_API_PORT: 3421 }); }}>
              Сбросить на 3421
            </button>
          </div>
          
<div className="hint" style={{ marginTop: 16 }}>Действия с нодой</div>
          <div className="row" style={{ marginTop: 8 }}>
            <button
              className="primary"
              disabled={!nodeUp}
              onClick={async () => {
                if (!window.confirm("Пересинхронизировать ноду? Цепь будет пересобрана, это может занять время.")) return;
                try {
                  const ok = await resyncNode(net);
                  setMessage(ok ? "пересинхронизация запущена" : "нода не приняла запрос");
                } catch (e) {
                  setMessage(String(e));
                }
              }}
            >
              Пересинхронизировать ноду
            </button>
            <button className="ghost" onClick={() => openLogFile(net)}>
              Открыть лог ноды
            </button>
          </div>
        </div>

        <details>
          <summary className="hint" style={{ cursor: "pointer", padding: "4px 0" }}>Дополнительно: P2P-пиры</summary>
        <div className="panel">
          <div className="k">P2P settings</div>
          {(["PREFERRED_PEERS", "ALLOWED_PEERS", "BLOCKED_PEERS"] as const).map((key) => (
            <div key={key} style={{ marginTop: 12 }}>
              <div className="hint">{key.replace("_", " ").toLowerCase()}</div>
              <textarea
                className="peer-box"
                value={Array.isArray(p2p[key]) ? (p2p[key] as string[]).join("\n") : ""}
                onChange={(e) => updateP2P({ [key]: e.target.value.split("\n").filter(Boolean) })}
              />
            </div>
          ))}
        </div>
        </details>
      </div>

      <details>
        <summary className="hint" style={{ cursor: "pointer", padding: "4px 0" }}>Дополнительно: raw server_config.json</summary>
      <div className="panel" id="raw-config">
        <div className="k">server_config.json</div>
        <textarea value={raw} onChange={(e) => setRaw(e.target.value)} />
        <div className="row" style={{ marginTop: 10 }}>
          <button
            className="ghost"
            onClick={() => {
              try {
                save(JSON.parse(raw));
              } catch (e) {
                setMessage(String(e));
              }
            }}
          >
            Сохранить raw
          </button>
          {message && <span className="hint">{message}</span>}
        </div>
      </div>
      </details>
    </div>
  );
}

// Точная конвертация GRIN ↔ нано-GRIN без float (в UI это была ошибка U-09/F-04).

const NANOS_PER_GRIN = 1_000_000_000n;

export function grinToNanos(value: string): bigint {
  const text = value.trim().replace(",", ".");
  if (text === "") throw new Error("пустое значение");
  if (!/^\d+(\.\d{0,9})?$/.test(text)) throw new Error(`некорректная сумма: ${value}`);

  const [intPart, fracPart = ""] = text.split(".");
  const frac = (fracPart + "000000000").slice(0, 9);
  return BigInt(intPart) * NANOS_PER_GRIN + BigInt(frac);
}

export function nanosToGrin(nanos: bigint | number | string | null | undefined): string {
  if (nanos === null || nanos === undefined) return "—";
  const value = BigInt(nanos);
  const negative = value < 0n;
  const abs = negative ? -value : value;
  const intPart = abs / NANOS_PER_GRIN;
  const frac = (abs % NANOS_PER_GRIN).toString().padStart(9, "0").replace(/0+$/, "");
  return `${negative ? "-" : ""}${intPart}${frac ? "." + frac : ""}`;
}

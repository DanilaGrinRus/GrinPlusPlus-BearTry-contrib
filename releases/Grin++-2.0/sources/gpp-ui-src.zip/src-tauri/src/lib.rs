// Тонкий Tauri-слой: команды, состояние процесса ноды, инициализация приложения.
// Вся предметная логика — в `engine` (не зависит от Tauri и тестируется отдельно).

#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

pub mod engine;

use serde_json::Value;
use std::process::Child;
use std::sync::Mutex;
use tauri::menu::{Menu, MenuItem};
use tauri::tray::TrayIconBuilder;
use tauri::{Manager, State};

pub use engine::AppPaths;

struct AppState {
    node: Mutex<Option<Child>>,
}

#[tauri::command]
fn app_paths(net: Option<String>) -> AppPaths {
    engine::resolve_paths(net.as_deref().unwrap_or(engine::DEFAULT_NET))
}

#[tauri::command]
fn node_running(state: State<'_, AppState>) -> bool {
    let mut guard = state.node.lock().unwrap();
    match guard.as_mut() {
        Some(child) => match child.try_wait() {
            Ok(None) => true,
            _ => {
                *guard = None;
                false
            }
        },
        None => false,
    }
}

#[tauri::command]
fn start_node(state: State<'_, AppState>, floonet: bool, no_wallet: bool) -> Result<u32, String> {
    let mut guard = state.node.lock().unwrap();
    if let Some(child) = guard.as_mut() {
        if child.try_wait().map(|s| s.is_none()).unwrap_or(false) {
            return Err("node is already running".into());
        }
        *guard = None;
    }

    let child = engine::start_node(floonet, no_wallet)?;
    let pid = child.id();
    *guard = Some(child);
    Ok(pid)
}


#[tauri::command]
async fn stop_node(state: State<'_, AppState>) -> Result<(), String> {
    // Сначала штатная остановка через admin REST: нода успевает закрыть БД.
    let _ = engine::request_shutdown("MAINNET").await;
    let _ = engine::request_shutdown("FLOONET").await;

    // Затем ждём завершения процесса; kill — только запасной вариант.
    let child_opt = { state.node.lock().unwrap().take() };
    if let Some(mut child) = child_opt {
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(15);
        loop {
            match child.try_wait() {
                Ok(Some(_)) => return Ok(()),
                Ok(None) => {
                    if std::time::Instant::now() >= deadline {
                        break;
                    }
                    std::thread::sleep(std::time::Duration::from_millis(200));
                }
                Err(_) => break,
            }
        }
        child.kill().map_err(|e| format!("kill failed: {e}"))?;
        let _ = child.wait();
    }
    Ok(())
}
#[tauri::command]
async fn node_health(net: Option<String>) -> Result<Value, String> {
    engine::node_health(net.as_deref().unwrap_or(engine::DEFAULT_NET)).await
}

#[tauri::command]
async fn node_status(net: Option<String>) -> Result<Value, String> {
    engine::node_status(net.as_deref().unwrap_or(engine::DEFAULT_NET)).await
}

#[tauri::command]
fn read_log_tail(net: Option<String>, lines: usize) -> Result<Vec<String>, String> {
    engine::read_log_tail(net.as_deref().unwrap_or(engine::DEFAULT_NET), lines)
}

#[tauri::command]
fn log_tail_named(net: String, name: String, lines: usize) -> Result<Vec<String>, String> {
    engine::read_log_tail_named(&net, &name, lines)
}

#[tauri::command]
fn ui_log(net: String, level: String, message: String) -> Result<(), String> {
    engine::append_ui_log(&net, &level, &message)
}

#[tauri::command]
fn tor_running(net: String) -> bool {
    engine::tor_running(&net)
}

#[tauri::command]
async fn resync_node(net: String) -> Result<bool, String> {
    engine::resync_node(&net).await
}

#[tauri::command]
fn read_net_config(net: Option<String>) -> Result<Value, String> {
    engine::read_net_config(net.as_deref().unwrap_or(engine::DEFAULT_NET))
}

#[tauri::command]
fn save_net_config(net: Option<String>, config: Value) -> Result<(), String> {
    engine::save_net_config(net.as_deref().unwrap_or(engine::DEFAULT_NET), &config)
}

#[tauri::command]
fn api_secret_present(net: Option<String>) -> bool {
    engine::api_secret_present(net.as_deref().unwrap_or(engine::DEFAULT_NET))
}

#[tauri::command]
async fn wallet_rpc(net: Option<String>, method: String, params: Value) -> Result<Value, String> {
    engine::wallet_rpc(net.as_deref().unwrap_or(engine::DEFAULT_NET), &method, params).await
}

#[tauri::command]
async fn moat_map() -> Result<Value, String> {
    engine::moat_map().await
}

#[tauri::command]
async fn moat_fetch() -> Result<Value, String> {
    engine::moat_fetch().await
}

#[tauri::command]
async fn moat_check(id: String, challenge: String, solution: String) -> Result<Vec<String>, String> {
    engine::moat_check(&id, &challenge, &solution).await
}

#[tauri::command]
fn open_data_dir(net: Option<String>) -> Result<(), String> {
    let paths = engine::resolve_paths(net.as_deref().unwrap_or(engine::DEFAULT_NET));
    std::process::Command::new("explorer.exe")
        .arg(&paths.data_dir)
        .spawn()
        .map_err(|e| format!("cannot open data dir: {e}"))?;
    Ok(())
}

#[tauri::command]
fn open_log_file(net: Option<String>) -> Result<(), String> {
    let paths = engine::resolve_paths(net.as_deref().unwrap_or(engine::DEFAULT_NET));
    let logs_dir = std::path::Path::new(&paths.net_dir).join("LOGS");
    std::fs::create_dir_all(&logs_dir).map_err(|e| format!("cannot create logs dir: {e}"))?;
    std::process::Command::new("explorer.exe")
        .arg(&logs_dir)
        .spawn()
        .map_err(|e| format!("cannot open log file: {e}"))?;
    Ok(())
}
fn configure_webview_data_dir() {
    if std::env::var_os("WEBVIEW2_USER_DATA_FOLDER").is_some() {
        return;
    }
    let Ok(exe) = std::env::current_exe() else { return };
    let Some(dir) = exe.parent() else { return };
    let candidate = dir.join(".webview2");
    if std::fs::create_dir_all(&candidate).is_ok() {
        std::env::set_var("WEBVIEW2_USER_DATA_FOLDER", candidate);
    }
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    // Профиль WebView2 держим рядом с приложением (portable), как и данные ноды:
    // в ограниченных окружениях запись в %LOCALAPPDATA% может быть запрещена.
    configure_webview_data_dir();

    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_clipboard_manager::init())
        .manage(AppState {
            node: Mutex::new(None),
        })
        .setup(|app| {
            let show = MenuItem::with_id(app, "show", "Показать", true, None::<&str>)?;
            let hide = MenuItem::with_id(app, "hide", "Скрыть в трей", true, None::<&str>)?;
            let quit = MenuItem::with_id(app, "quit", "Выход", true, None::<&str>)?;
            let menu = Menu::with_items(app, &[&show, &hide, &quit])?;

            if let Some(icon) = app.default_window_icon().cloned() {
                TrayIconBuilder::new()
                    .icon(icon)
                    .menu(&menu)
                    .tooltip("Grin++")
                    .on_menu_event(|app, event| match event.id.as_ref() {
                        "show" => {
                            if let Some(w) = app.get_webview_window("main") {
                                let _ = w.show();
                                let _ = w.set_focus();
                            }
                        }
                        "hide" => {
                            if let Some(w) = app.get_webview_window("main") {
                                let _ = w.hide();
                            }
                        }
                        "quit" => app.exit(0),
                        _ => {}
                    })
                    .build(app)?;
            }
            Ok(())
        })        .invoke_handler(tauri::generate_handler![
            app_paths,
            node_running,
            start_node,
            stop_node,
            node_health,
            node_status,
            read_log_tail,
            log_tail_named,
        ui_log,
        tor_running,
        resync_node,
            read_net_config,
            save_net_config,
            api_secret_present,
            wallet_rpc,
            moat_map,
            moat_fetch,
            moat_check,
            open_data_dir,
            open_log_file
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}

// rebuild 2026-11-10T21:56:20.3000435+07:00

// rebuild 2026-11-10T22:20:21.4825796+07:00

// rebuild 2026-11-10T22:22:25.8257053+07:00

// rebuild 2026-11-10T23:06:44.5993888+07:00

// rebuild 2026-11-10T23:20:29.3418961+07:00

// rebuild 2026-11-10T23:42:34.1656088+07:00

// rebuild 2026-11-10T23:47:21.8839438+07:00

// rebuild 2026-11-10T23:55:55.6081953+07:00

// rebuild 2026-11-11T00:01:59.0238078+07:00

// rebuild 2026-11-11T00:05:11.9628420+07:00

// rebuild 2026-11-11T00:59:56.6490887+07:00

// rebuild 2026-11-11T01:03:27.2629503+07:00

// rebuild 2026-11-11T04:05:45.5851745+07:00

// rebuild 2026-11-11T15:34:24.7840258+07:00

// ui rebuild 2026-11-12T01:53:16.3077296+07:00

// ui rebuild p2 2026-11-12T01:56:03.1599920+07:00

// ui rebuild labels 2026-11-12T01:56:58.8317707+07:00

// ui rebuild labels2 2026-11-12T01:57:39.4571620+07:00

// ui rebuild badge 2026-11-12T02:03:56.8502621+07:00

// ui rebuild list 2026-11-12T02:14:27.8272579+07:00

// ui rebuild stages 2026-11-12T02:17:55.3576470+07:00

// ui rebuild nav/logs 2026-11-12T02:30:31.5945731+07:00

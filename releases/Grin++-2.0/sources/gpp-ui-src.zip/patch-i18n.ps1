# patch-i18n.ps1 — добивает перевод длинных подсказок и сообщений в App.tsx.
$f = 'C:\DHW\Gplus\work\gpp-ui-tauri-20261110\src\App.tsx'
$t = [System.IO.File]::ReadAllText($f)

$pairs = @(
    @('api_secret: {secretPresent ? "есть" : "нет"}', '{t("top.apiSecret")}: {secretPresent ? t("common.yes") : t("common.no")}'),
    @('<div className="k">процесс</div><div className="v">{running ? "запущена" : "остановлена"}</div>', '<div className="k">{t("status.process")}</div><div className="v">{running ? t("status.running") : t("status.stopped")}</div>'),
    @('<div className="k">заголовки</div>', '<div className="k">{t("status.headers")}</div>'),
    @('<div className="k">блоки</div>', '<div className="k">{t("status.blocks")}</div>'),
    @('Всё, что создаёт нода, лежит в её папке: ', '{t("status.dataHint")} '),
    @('<div className="k">каталог сети</div>', '<div className="k">{t("status.netDir")}</div>'),
    @('<div className="k">REST порт</div>', '<div className="k">{t("status.restPort")}</div>'),
    @('<div className="k">wallet порт</div>', '<div className="k">{t("status.walletPort")}</div>'),
    @('setMessage("кошелёк создан — сохраните seed")', 'setMessage(t("wallet.created"))'),
    @('setMessage("кошелёк восстановлен")', 'setMessage(t("wallet.restored"))'),
    @('setMessage("вход выполнен")', 'setMessage(t("wallet.loggedIn"))'),
    @('setMessage("пароль изменён")', 'setMessage(t("wallet.passwordChanged"))'),
    @('setMessage("кошелёк удалён")', 'setMessage(t("wallet.deleted"))'),
    @('setMessage("все сессии закрыты")', 'setMessage(t("wallet.sessionsClosed"))'),
    @('placeholder="новый пароль"', 'placeholder={t("wallet.newPassword")}'),
    @('<div className="k">seed (показывается один раз)</div>', '<div className="k">{t("wallet.seedOnce")}</div>'),
    @('>Восстановить этим seed<', '>{t("wallet.restoreWithSeed")}<'),
    @('>Скрыть<', '>{t("wallet.hide")}<'),
    @('<div className="hint">нет данных</div>', '<div className="hint">{t("common.noData")}</div>'),
    @('{lines.join("\n") || "нет данных"}', '{lines.join("\n") || t("logs.noData")}'),
    @('setMessage(`статус: ${pick(result, "status")}`)', 'setMessage(`${t("common.status")}: ${pick(result, "status")}`)'),
    @('setMessage(`финализация: ${pick(result, "status")}, broadcast: ${pick(result, "broadcast")}`)', 'setMessage(`${t("send.finalize")}: ${pick(result, "status")}, broadcast: ${pick(result, "broadcast")}`)'),
    @('setMessage("скопировано")', 'setMessage(t("common.copied"))'),
    @('setMessage(`копирование недоступно: ${String(e)}`)', 'setMessage(`${t("common.copyUnavailable")}: ${String(e)}`)'),
    @('комиссия: {fee} GRIN', '{t("send.fee")}: {fee} GRIN'),
    @('>S1: slatepack для получателя<', '>{t("send.slatepackOut")}<'),
    @('>S3: финализация ответного slatepack<', '>{t("send.finalizeBlock")}<'),
    @('>Ответный slatepack (вернуть отправителю)<', '>{t("receive.responseOut")}<'),
    @('>История транзакций<', '>{t("history.title")}<'),
    @('>Логи ноды<', '>{t("logs.title")}<'),
    @('>Мосты Tor<', '>{t("tor.title")}<'),
    @('>Предложенные obfs4-мосты<', '>{t("tor.offered")}<'),
    @('setMessage(`отмена: ${pick(result, "status")}`)', 'setMessage(`${t("history.cancel")}: ${pick(result, "status")}`)'),
    @('setMessage(`повтор: ${pick(result, "status")}`)', 'setMessage(`${t("history.repost")}: ${pick(result, "status")}`)'),
    @(' авто</label>', ' {t("logs.auto")}</label>'),
    @('setStatus("сохранено")', 'setStatus(t("settings.saved"))'),
    @('setStatus(`ошибка: ${String(e)}`)', 'setStatus(`${t("settings.error")}: ${String(e)}`)'),
    @('setMessage(`BridgeDB отдал ${map.obfs4.length} obfs4-мост(ов)`)', 'setMessage(`${t("tor.gotBridges")} ${map.obfs4.length}`)'),
    @('setMessage("нужно решить CAPTCHA")', 'setMessage(t("tor.needCaptcha"))'),
    @('setMessage(`получено ${list.length} мостов`)', 'setMessage(`${t("tor.received")} ${list.length}`)'),
    @('setMessage(`применено: ${pick(result, "status")}, тип ${pick(result, "bridges_type")}`)', 'setMessage(`${t("tor.applied")}: ${pick(result, "status")}, ${t("common.type")} ${pick(result, "bridges_type")}`)'),
    @('snowflake из карты: {snowflake}', '{t("tor.snowflakeFromMap")}: {snowflake}'),
    @('placeholder="ответ с картинки"', 'placeholder={t("tor.captchaAnswer")}'),
    @('>Проверить<', '>{t("tor.check")}<'),
    @('>Отмена<', '>{t("tor.cancel")}<'),
    @('<div className="hint">тип: {bridgesType || "—"}; мостов: {bridges.length}</div>', '<div className="hint">{t("common.type")}: {bridgesType || "—"}; {t("tor.bridgesCount")}: {bridges.length}</div>')
)

$applied = 0
$missing = @()
foreach ($p in $pairs) {
    if ($t.Contains($p[0])) {
        $t = $t.Replace($p[0], $p[1])
        $applied++
    } else {
        $missing += $p[0]
    }
}

[System.IO.File]::WriteAllText($f, $t, (New-Object System.Text.UTF8Encoding($false)))
Write-Output "applied=$applied total=$($pairs.Count)"
if ($missing.Count -gt 0) {
    Write-Output '--- не найдено ---'
    $missing | ForEach-Object { Write-Output $_ }
}

import json, base64
d = json.load(open(r"C:\DHW\Gplus\work\gpp-ui-tauri-20261110\moat-fetch.json", encoding="utf-8"))
first = (d.get("data") or [{}])[0]
print("type:", first.get("type"))
print("id_len:", len(first.get("id", "")), "challenge_len:", len(first.get("challenge", "")))
img = first.get("image", "")
print("image_b64_len:", len(img), "decodes:", end=" ")
try:
    base64.b64decode(img[:64] + "==" * (len(img) % 4 != 0))
    print("yes")
except Exception as e:
    print("no", e)

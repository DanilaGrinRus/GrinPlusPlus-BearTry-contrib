$ErrorActionPreference = 'Stop'
$nl = "`r`n"
$f = 'C:\DHW\Gplus\work\gpp-ui-tauri-20261110\src\ConsoleSettings.tsx'
$t = [System.IO.File]::ReadAllText($f)

# 1) logs page: remove duplicated node stats grid
$pattern = '(?s)      <div style=\{\{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32, marginBottom: 18 \}\}>.*?      <div className="k">Logs</div>'
$t = [regex]::Replace($t, $pattern, '      <div className="k">Logs</div>')
if ($t.Contains('gap: 32, marginBottom: 18')) { throw 'stats grid still present' }

# 2) logs page: remove duplicated peers footer
$pattern = '(?s)\r?\n      <div className="k" style=\{\{ marginTop: 18 \}\}>Connected Peers</div>.*?\r?\n      </div>'
$t = [regex]::Replace($t, $pattern, '')
if ($t.Contains('Connected Peers')) { throw 'peers footer still present' }

# 3) settings: wrap P2P panel in <details>
$pattern = '(?s)(        <div className="panel">\r?\n          <div className="k">P2P settings</div>.*?\r?\n        </div>)\r?\n      </div>'
$m = [regex]::Match($t, $pattern)
if (-not $m.Success) { throw 'p2p panel pattern missing' }
$p2p = $m.Groups[1].Value
$replacement = '        <details>' + $nl + '          <summary className="hint" style={{ cursor: "pointer", padding: "4px 0" }}>Дополнительно: P2P-пиры</summary>' + $nl + $p2p + $nl + '        </details>' + $nl + '      </div>'
$t = $t.Remove($m.Index, $m.Length).Insert($m.Index, $replacement)

# 4) settings: remove dead Tor settings panel
$pattern = '(?s)\r?\n      <div className="panel">\r?\n        <div className="k">Tor settings</div>.*?\r?\n      </div>\r?\n(?=\r?\n      <div className="panel" id="raw-config">)'
$t = [regex]::Replace($t, $pattern, '')
if ($t.Contains('Bridges help you access')) { throw 'dead tor panel still present' }

# 5) settings: wrap raw config panel into details
$pattern = '(?s)(      <div className="panel" id="raw-config">.*?\r?\n      </div>)\r?\n    </div>\r?\n  \);\r?\n\}'
$m = [regex]::Match($t, $pattern)
if (-not $m.Success) { throw 'raw panel pattern missing' }
$raw = $m.Groups[1].Value
$replacement = '      <details>' + $nl + '        <summary className="hint" style={{ cursor: "pointer", padding: "4px 0" }}>Дополнительно: raw server_config.json</summary>' + $nl + $raw + $nl + '      </details>' + $nl + '    </div>' + $nl + '  );' + $nl + '}'
$t = $t.Remove($m.Index, $m.Length).Insert($m.Index, $replacement)

[System.IO.File]::WriteAllText($f, $t, (New-Object System.Text.UTF8Encoding($false)))
Write-Output 'ConsoleSettings P2 patched'

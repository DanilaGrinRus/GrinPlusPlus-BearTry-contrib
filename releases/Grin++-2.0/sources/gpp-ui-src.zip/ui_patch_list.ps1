$ErrorActionPreference = 'Stop'
$nl = "`r`n"
$f = 'C:\DHW\Gplus\work\gpp-ui-tauri-20261110\src\App.tsx'
$t = [System.IO.File]::ReadAllText($f)

# ---------- imports ----------
$t = $t.Replace('import { useCallback, useEffect, useMemo, useState, type ReactElement } from "react";',
                'import { useCallback, useEffect, useMemo, useRef, useState, type ReactElement } from "react";')
$t = $t.Replace('import { writeText } from "@tauri-apps/plugin-clipboard-manager";',
                'import { writeText } from "@tauri-apps/plugin-clipboard-manager";' + $nl + 'import QRCode from "qrcode";')

# ---------- App: privacy state ----------
$t = $t.Replace('  const [hudBalance, setHudBalance] = useState<Record<string, unknown> | null>(null);',
                '  const [hudBalance, setHudBalance] = useState<Record<string, unknown> | null>(null);' + $nl + '  const [hideBalance, setHideBalance] = useState(false);')
# pass to wallet
$t = $t.Replace('<WalletPage net={net} enabled={nodeUp} call={call} session={session} onSession={setSession} onNavigate={setPage} onBalance={setHudBalance} />',
                '<WalletPage net={net} enabled={nodeUp} call={call} session={session} onSession={setSession} onNavigate={setPage} onBalance={setHudBalance} hideBalance={hideBalance} onToggleHideBalance={() => setHideBalance((v) => !v)} />')
# HUD mask + toggle button
$t = $t.Replace('              · {session.username} · {pick(hudBalance, "fmt_spendable")} GRIN',
                '              · {session.username} · {hideBalance ? "••••••" : pick(hudBalance, "fmt_spendable")} GRIN')
$t = $t.Replace('          <span>{pick(status, "connections")} ↑ 0 ↓</span>',
                '          <button className="ghost" style={{ padding: "0 6px" }} onClick={() => setHideBalance((v) => !v)}>' + $nl + '            {hideBalance ? "показать баланс" : "скрыть баланс"}' + $nl + '          </button>' + $nl + '          <span>{pick(status, "connections")} ↑ 0 ↓</span>')

# ---------- WalletPage props ----------
$t = $t.Replace('  onBalance?: (b: Record<string, unknown> | null) => void;' + $nl + '}) {' + $nl + '  const { enabled, call, session, onSession, onNavigate, onBalance } = props;',
                '  onBalance?: (b: Record<string, unknown> | null) => void;' + $nl + '  hideBalance?: boolean;' + $nl + '  onToggleHideBalance?: () => void;' + $nl + '}) {' + $nl + '  const { enabled, call, session, onSession, onNavigate, onBalance, hideBalance, onToggleHideBalance } = props;')
# mask wallet balance and add toggle
$t = $t.Replace('          <div className="spendable">{pick(balance, "fmt_spendable")}</div>',
                '          <div className="spendable">{hideBalance ? "••••••" : pick(balance, "fmt_spendable")}</div>')
$t = $t.Replace('            <button className="ghost" onClick={refreshDashboard}>' + $nl + '              {t("receive.refresh")}' + $nl + '            </button>',
                '            <button className="ghost" onClick={refreshDashboard}>' + $nl + '              {t("receive.refresh")}' + $nl + '            </button>' + $nl + '            <button className="ghost" onClick={onToggleHideBalance}>' + $nl + '              {hideBalance ? "показать баланс" : "скрыть баланс"}' + $nl + '            </button>')

# ---------- History: filters select ----------
$old = '      <div className="tabs" style={{ marginBottom: 12 }}>' + $nl + '        {tabs.map((tab) => (' + $nl + '          <button' + $nl + '            key={tab.id}' + $nl + '            className={`tab ${filter === tab.id ? "active" : ""}`}' + $nl + '            onClick={() => setFilter(tab.id)}' + $nl + '          >' + $nl + '            {tab.label}' + $nl + '          </button>' + $nl + '        ))}' + $nl + '      </div>'
$new = '      <div className="row" style={{ marginBottom: 12 }}>' + $nl + '        <span className="hint">фильтр:</span>' + $nl + '        <select value={filter} onChange={(e) => setFilter(e.target.value)}>' + $nl + '          {tabs.map((tab) => (' + $nl + '            <option key={tab.id} value={tab.id}>{tab.label}</option>' + $nl + '          ))}' + $nl + '        </select>' + $nl + '        <button className="ghost" onClick={exportCsv} disabled={!session}>Экспорт</button>' + $nl + '      </div>'
if (-not $t.Contains($old)) { throw 'history tabs anchor missing' }
$t = $t.Replace($old, $new)
# drop old export button from header
$t = $t.Replace('        <button className="ghost" onClick={exportCsv} disabled={!session}>export</button>' + $nl + '        {message && <span className="hint">{message}</span>}', '        {message && <span className="hint">{message}</span>}')

# ---------- StatusPage: progress bar + details ----------
$old = '  const { paths, running, health, status } = props;' + $nl + '  return ('
$new = '  const { paths, running, health, status } = props;' + $nl + '  const chain = Number((status?.chain as Record<string, unknown> | undefined)?.height ?? NaN);' + $nl + '  const netHeight = Number((status?.network as Record<string, unknown> | undefined)?.height ?? NaN);' + $nl + '  const sync = String(pick(status, "sync_status"));' + $nl + '  const lastSample = useRef<{ h: number; t: number } | null>(null);' + $nl + '  let percent: number | null = null;' + $nl + '  let eta = "";' + $nl + '  if (Number.isFinite(chain) && Number.isFinite(netHeight) && netHeight > 0) {' + $nl + '    percent = Math.max(0, Math.min(100, Math.round((chain / netHeight) * 100)));' + $nl + '  }' + $nl + '  if (lastSample.current && chain > lastSample.current.h) {' + $nl + '    const minutes = (Date.now() - lastSample.current.t) / 60000;' + $nl + '    if (minutes > 0.2) {' + $nl + '      const rate = (chain - lastSample.current.h) / minutes;' + $nl + '      if (rate > 0 && Number.isFinite(netHeight) && netHeight > chain) {' + $nl + '        const left = Math.round((netHeight - chain) / rate);' + $nl + '        eta = left <= 1 ? "<1 мин" : left < 60 ? `${left} мин` : `${Math.floor(left / 60)} ч ${left % 60} мин`;' + $nl + '      }' + $nl + '    }' + $nl + '  }' + $nl + '  lastSample.current = { h: chain, t: Date.now() };' + $nl + '  return ('
if (-not $t.Contains($old)) { throw 'status signature anchor missing' }
$t = $t.Replace($old, $new)

# progress bar markup after sync kv row
$old = '          <div className="kv"><div className="k">{t("status.blocks")}</div><div className="v">{String((status?.chain as Record<string, unknown> | undefined)?.height ?? pick(status, "chain_height"))}</div></div>' + $nl + '        </div>'
$new = '          <div className="kv"><div className="k">{t("status.blocks")}</div><div className="v">{String((status?.chain as Record<string, unknown> | undefined)?.height ?? pick(status, "chain_height"))}</div></div>' + $nl + '        </div>' + $nl + '        {sync !== "FULLY_SYNCED" && percent !== null && (' + $nl + '          <div style={{ marginTop: 14 }}>' + $nl + '            <div className="progress"><div style={{ width: `${percent}%` }} /></div>' + $nl + '            <div className="hint" style={{ marginTop: 4 }}>' + $nl + '              {sync} · {percent}%{eta ? ` · осталось ~${eta}` : ""}' + $nl + '            </div>' + $nl + '          </div>' + $nl + '        )}'
if (-not $t.Contains($old)) { throw 'status blocks anchor missing' }
$t = $t.Replace($old, $new)

# move health/tip/sync into collapsible details
$old = '          <div className="kv"><div className="k">health</div><div className="v">{health ? pick(health, "status") : "—"}</div></div>' + $nl + '          <div className="kv"><div className="k">tip</div><div className="v">{String((status?.tip as Record<string, unknown> | undefined)?.height ?? pick(status, "tip"))}</div></div>' + $nl + '          <div className="kv"><div className="k">sync</div><div className="v">{pick(status, "sync_status")}</div></div>' + $nl
$new = ''
if (-not $t.Contains($old)) { throw 'status details anchor missing' }
$t = $t.Replace($old, $new)
$old = '          <div className="kv"><div className="k">{t("status.blocks")}</div><div className="v">{String((status?.chain as Record<string, unknown> | undefined)?.height ?? pick(status, "chain_height"))}</div></div>' + $nl + '        </div>' + $nl + '        {sync !== "FULLY_SYNCED" && percent !== null && ('
$new = '          <div className="kv"><div className="k">{t("status.blocks")}</div><div className="v">{String((status?.chain as Record<string, unknown> | undefined)?.height ?? pick(status, "chain_height"))}</div></div>' + $nl + '        </div>' + $nl + '        <details style={{ marginTop: 8 }}>' + $nl + '          <summary className="hint" style={{ cursor: "pointer" }}>Подробнее</summary>' + $nl + '          <div className="grid" style={{ marginTop: 8 }}>' + $nl + '            <div className="kv"><div className="k">health</div><div className="v">{health ? pick(health, "status") : "—"}</div></div>' + $nl + '            <div className="kv"><div className="k">tip</div><div className="v">{String((status?.tip as Record<string, unknown> | undefined)?.height ?? pick(status, "tip"))}</div></div>' + $nl + '            <div className="kv"><div className="k">sync</div><div className="v">{pick(status, "sync_status")}</div></div>' + $nl + '          </div>' + $nl + '        </details>' + $nl + '        {sync !== "FULLY_SYNCED" && percent !== null && ('
if (-not $t.Contains($old)) { throw 'status progress anchor missing' }
$t = $t.Replace($old, $new)

# ---------- Receive: QR + new address under details ----------
$t = $t.Replace('  const [outgoing, setOutgoing] = useState<string | null>(null);' + $nl + '  const [message, setMessage] = useState<string | null>(null);',
                '  const [outgoing, setOutgoing] = useState<string | null>(null);' + $nl + '  const [message, setMessage] = useState<string | null>(null);' + $nl + '  const [qr, setQr] = useState("");' + $nl + $nl + '  useEffect(() => {' + $nl + '    const address = session?.address;' + $nl + '    if (!address) {' + $nl + '      setQr("");' + $nl + '      return;' + $nl + '    }' + $nl + '    QRCode.toDataURL(address, { margin: 1, width: 180 }).then(setQr).catch(() => setQr(""));' + $nl + '  }, [session?.address]);')

$old = '        <div className="row">' + $nl + '          <code style={{ wordBreak: "break-all" }}>{session?.address || "—"}</code>' + $nl + '          <button className="ghost" onClick={loadAddress} disabled={!enabled || !session}>{t("receive.refresh")}</button>' + $nl + '          <button className="ghost" onClick={newAddress} disabled={!enabled || !session}>{t("receive.newAddress")}</button>' + $nl + '          <button className="ghost" onClick={() => session?.address && copy(session.address)} disabled={!session?.address}>' + $nl + '            {t("common.copy")}' + $nl + '          </button>' + $nl + '        </div>'
$new = '        <div className="row">' + $nl + '          <code style={{ wordBreak: "break-all" }}>{session?.address || "—"}</code>' + $nl + '          <button className="ghost" onClick={loadAddress} disabled={!enabled || !session}>{t("receive.refresh")}</button>' + $nl + '          <button className="ghost" onClick={() => session?.address && copy(session.address)} disabled={!session?.address}>' + $nl + '            {t("common.copy")}' + $nl + '          </button>' + $nl + '        </div>' + $nl + '        {qr && (' + $nl + '          <div className="row" style={{ marginTop: 12, alignItems: "flex-start" }}>' + $nl + '            <img className="qr" src={qr} alt="QR адреса" />' + $nl + '            <span className="hint">QR для получателя: тот же slatepack-адрес.</span>' + $nl + '          </div>' + $nl + '        )}' + $nl + '        <details style={{ marginTop: 12 }}>' + $nl + '          <summary className="hint" style={{ cursor: "pointer" }}>Дополнительно</summary>' + $nl + '          <div className="hint" style={{ marginTop: 6 }}>Новый адрес нужен редко: старый останется рабочим, но перестанет показываться.</div>' + $nl + '          <button className="ghost" style={{ marginTop: 6 }} onClick={newAddress} disabled={!enabled || !session}>{t("receive.newAddress")}</button>' + $nl + '        </details>'
if (-not $t.Contains($old)) { throw 'receive address row anchor missing' }
$t = $t.Replace($old, $new)

[System.IO.File]::WriteAllText($f, $t, (New-Object System.Text.UTF8Encoding($false)))
Write-Output 'App items 1,2,3,5 patched'

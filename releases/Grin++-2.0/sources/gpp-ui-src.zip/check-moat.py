import json
p = r"C:\DHW\Gplus\work\gpp-ui-tauri-20261110\moat-map.json"
d = json.load(open(p, encoding="utf-8"))
print("countries:", len(d))
for country, v in list(d.items())[:3]:
    settings = v.get("settings", [])
    kinds = [(s.get("bridges") or {}).get("type") for s in settings]
    counts = [len((s.get("bridges") or {}).get("bridge_strings", [])) for s in settings]
    print(country, kinds, counts)
obfs4 = 0
for v in d.values():
    for s in v.get("settings", []):
        b = s.get("bridges") or {}
        if b.get("type") == "obfs4":
            obfs4 += len(b.get("bridge_strings", []))
print("total obfs4 lines:", obfs4)

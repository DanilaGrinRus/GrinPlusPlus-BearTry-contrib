$ErrorActionPreference = 'Stop'
$nl = "`r`n"
$f = 'C:\DHW\Gplus\work\gpp-ui-tauri-20261110\src\App.tsx'
$t = [System.IO.File]::ReadAllText($f)

# --- status: tip as height, blocks from chain.height ---
$old = '          <div className="kv"><div className="k">tip</div><div className="v">{pick(status, "tip").slice(0, 90)}{pick(status, "tip").length > 90 ? "…" : ""}</div></div>'
$new = '          <div className="kv"><div className="k">tip</div><div className="v">{String((status?.tip as Record<string, unknown> | undefined)?.height ?? pick(status, "tip"))}</div></div>'
if (-not $t.Contains($old)) { throw 'tip anchor missing' }
$t = $t.Replace($old, $new)
$old = '          <div className="kv"><div className="k">{t("status.blocks")}</div><div className="v">{pick(status, "chain_height")}</div></div>'
$new = '          <div className="kv"><div className="k">{t("status.blocks")}</div><div className="v">{String((status?.chain as Record<string, unknown> | undefined)?.height ?? pick(status, "chain_height"))}</div></div>'
if (-not $t.Contains($old)) { throw 'blocks anchor missing' }
$t = $t.Replace($old, $new)

# --- history: actions only for active transactions ---
$old = '              const txAmount = tx.amount_credited ?? tx.amount_debited ?? tx.amount;' + $nl +
       '              const txState = tx.confirmed_height ? `confirmed @${tx.confirmed_height}` : (tx.status ?? tx.state ?? "pending");'
$new = $old + $nl +
       '              const txType = firstOf(["tx_type", "type"]);' + $nl +
       '              const txActive = !tx.confirmed_height && txType !== "Canceled" && txType !== "Received";'
if (-not $t.Contains($old)) { throw 'history vars anchor missing' }
$t = $t.Replace($old, $new)
$old = '                    <td style={{ padding: 6 }}>'+$nl+
       '                    <button className="ghost" onClick={() => onCancel(id)}>{t("history.cancel")}</button>{" "}'+$nl+
       '                    <button className="ghost" onClick={() => onRepost(id)}>{t("history.repost")}</button>'+$nl+
       '                  </td>'
$new = '                    <td style={{ padding: 6 }}>'+$nl+
       '                    {txActive ? ('+$nl+
       '                      <>'+$nl+
       '                        <button className="ghost" onClick={() => onCancel(id)}>{t("history.cancel")}</button>{" "}'+$nl+
       '                        <button className="ghost" onClick={() => onRepost(id)}>{t("history.repost")}</button>'+$nl+
       '                      </>'+$nl+
       '                    ) : ('+$nl+
       '                      <span className="hint">—</span>'+$nl+
       '                    )}'+$nl+
       '                  </td>'
if (-not $t.Contains($old)) { throw 'history actions anchor missing' }
$t = $t.Replace($old, $new)

# --- language: welcome buttons and form submit ---
$t = $t.Replace('          <button className="primary" onClick={() => setMode("create")}>'+$nl+'            Create Wallet'+$nl+'          </button>',
                '          <button className="primary" onClick={() => setMode("create")}>'+$nl+'            {t("wallet.create")}'+$nl+'          </button>')
$t = $t.Replace('          <button className="welcome-link" onClick={() => setMode("restore")}>'+$nl+'            Restore Wallet'+$nl+'          </button>',
                '          <button className="welcome-link" onClick={() => setMode("restore")}>'+$nl+'            {t("wallet.restore")}'+$nl+'          </button>')
$t = $t.Replace('            <button className="welcome-link" onClick={() => setMode("login")}>'+$nl+'              Login'+$nl+'            </button>',
                '            <button className="welcome-link" onClick={() => setMode("login")}>'+$nl+'              {t("wallet.login")}'+$nl+'            </button>')
$t = $t.Replace('                {mode === "create" ? "Create Wallet" : mode === "restore" ? "Restore Wallet" : "Login"}',
                '                {mode === "create" ? t("wallet.create") : mode === "restore" ? t("wallet.restore") : t("wallet.login")}')

[System.IO.File]::WriteAllText($f, $t, (New-Object System.Text.UTF8Encoding($false)))
Write-Output ('App P0 patched: tip=' + $t.Contains('status?.tip') + ' active=' + $t.Contains('txActive') + ' lang=' + $t.Contains('t("wallet.restore")'))

# --- logs + history strings in ConsoleSettings / App ---
$f2 = 'C:\DHW\Gplus\work\gpp-ui-tauri-20261110\src\ConsoleSettings.tsx'
$t2 = [System.IO.File]::ReadAllText($f2)
$t2 = $t2.Replace('>'+$nl+'          refresh'+$nl+'        </button>', '>'+$nl+'          обновить'+$nl+'        </button>')
$t2 = $t2.Replace('>'+$nl+'          open'+$nl+'        </button>', '>'+$nl+'          открыть'+$nl+'        </button>')
$t2 = $t2.Replace('<input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} /> auto', '<input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} /> авто')
[System.IO.File]::WriteAllText($f2, $t2, (New-Object System.Text.UTF8Encoding($false)))
Write-Output 'ConsoleSettings strings patched'

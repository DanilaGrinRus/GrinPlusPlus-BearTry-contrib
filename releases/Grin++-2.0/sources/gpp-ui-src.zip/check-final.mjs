import { chromium } from "playwright-core";
const b = await chromium.connectOverCDP("http://127.0.0.1:9232");
const p = b.contexts()[0].pages()[0];
await p.waitForSelector(".app .toolbar", { timeout: 20000 });
await p.locator('.toolbar button[title="Статус"]').click();
await p.waitForTimeout(400);
await p.getByRole("button", { name: "Запустить", exact: true }).click();
await p.waitForTimeout(15000);
const st = (await p.locator("main").innerText()).replace(/\n/g," | ").slice(0,140);
const t0=Date.now();
await p.getByRole("button", { name: "Стоп", exact: true }).click();
let ms=null;
for(let i=0;i<100;i++){ const x=await p.locator("main").innerText(); if(x.includes("остановлена")){ ms=Date.now()-t0; break;} await p.waitForTimeout(200); }
console.log("STATE:", st); console.log("STOP_MS:", ms);
await b.close();

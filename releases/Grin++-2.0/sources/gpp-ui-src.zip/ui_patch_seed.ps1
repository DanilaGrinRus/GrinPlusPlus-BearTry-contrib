$ErrorActionPreference = 'Stop'
$nl = "`r`n"
$u = 'C:\DHW\Gplus\work\gpp-ui-tauri-20261110'
$f = Join-Path $u 'src\App.tsx'
$t = [System.IO.File]::ReadAllText($f)

# 1) seed visibility state (hidden by default)
$anchor = '  const [seed, setSeed] = useState<string | null>(null);'
$add = $anchor + $nl + '  const [seedVisible, setSeedVisible] = useState(false);'
if (-not $t.Contains($anchor)) { throw 'seed state anchor missing' }
$t = $t.Replace($anchor, $add)

# when a new seed arrives it must not be shown immediately
$t = $t.Replace('      setSeed(result.wallet_seed ? String(result.wallet_seed) : null);',
                '      setSeed(result.wallet_seed ? String(result.wallet_seed) : null);' + $nl + '      setSeedVisible(false);')

# 2) collapsed seed panel: masked by default, "Показать/Скрыть" toggle
$old = '      {seed && (' + $nl +
'        <div className="panel">' + $nl +
'          <h2>{t("wallet.seedOnce")}</h2>' + $nl +
'          <div className="row">' + $nl +
'            <code className="address">{seed}</code>' + $nl +
'            <button className="ghost" onClick={() => onCopy(seed)}>' + $nl +
'              {t("common.copy")}' + $nl +
'            </button>' + $nl +
'            <button className="ghost" onClick={() => setSeed(null)}>' + $nl +
'              {t("wallet.hide")}' + $nl +
'            </button>' + $nl +
'          </div>' + $nl +
'          <div className="hint">{t("wallet.seedSavedHint")}</div>' + $nl +
'        </div>' + $nl +
'      )}'
$new = '      {seed && (' + $nl +
'        <div className="panel">' + $nl +
'          <h2>{t("wallet.seedOnce")}</h2>' + $nl +
'          <div className="row">' + $nl +
'            <span className="hint" style={{ flex: 1 }}>' + $nl +
'              {seedVisible ? "Сид-фраза показана на экране. Убедитесь, что рядом никого нет." : "Сид-фраза скрыта. Покажите её только чтобы записать, затем скройте."}' + $nl +
'            </span>' + $nl +
'            <button className="primary" onClick={() => setSeedVisible((v) => !v)}>' + $nl +
'              {seedVisible ? "Скрыть" : "Показать"}' + $nl +
'            </button>' + $nl +
'            <button className="ghost" onClick={() => onCopy(seed)}>' + $nl +
'              {t("common.copy")}' + $nl +
'            </button>' + $nl +
'            <button className="ghost" onClick={() => { setSeed(null); setSeedVisible(false); }}>' + $nl +
'              {t("wallet.hide")}' + $nl +
'            </button>' + $nl +
'          </div>' + $nl +
'          {seedVisible && (' + $nl +
'            <div className="row" style={{ marginTop: 8 }}>' + $nl +
'              <code className="address" style={{ wordBreak: "break-all" }}>{seed}</code>' + $nl +
'            </div>' + $nl +
'          )}' + $nl +
'          <div className="hint">{t("wallet.seedSavedHint")}</div>' + $nl +
'        </div>' + $nl +
'      )}'
if (-not $t.Contains($old)) { throw 'seed panel anchor missing' }
$t = $t.Replace($old, $new)

[System.IO.File]::WriteAllText($f, $t, (New-Object System.Text.UTF8Encoding($false)))
Write-Output ('App.tsx seed panel patched: ' + $t.Contains('setSeedVisible'))
